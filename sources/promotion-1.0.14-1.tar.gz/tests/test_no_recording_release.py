#!/usr/bin/env python3
"""Executable release-negative tests: mutate fixtures, build/extract real debs."""
import importlib.util
import io
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('no_recording', ROOT / 'scripts/verify-no-recording.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


def tar_bytes(files):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w:gz') as archive:
        for name, content in files.items():
            info = tarfile.TarInfo(name)
            info.size = len(content)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(content))
    return stream.getvalue()


def fixture_deb(path, payload):
    members = {'debian-binary': b'2.0\n',
               'control.tar.gz': tar_bytes({'control': b'Package: pm-host-fixture\nVersion: 1\nArchitecture: all\nMaintainer: test\nDescription: non-iOS fixture\n'}),
               'data.tar.gz': tar_bytes(payload)}
    result = bytearray(b'!<arch>\n')
    for name, data in members.items():
        result.extend(f'{name + "/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(data):<10}`\n'.encode())
        result.extend(data)
        if len(data) % 2:
            result.extend(b'\n')
    path.write_bytes(result)


class NoRecordingReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='pm-release-negative-')
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)

    def test_current_source_contract(self):
        self.assertEqual(checker.check_source(ROOT), [])

    def test_source_mutations_fail_but_historical_docs_are_allowed(self):
        repo = self.work / 'repo'
        shutil.copytree(ROOT, repo, ignore=shutil.ignore_patterns('.git', '__pycache__'))
        (repo / 'docs' / 'historical-recording.md').write_text('ProMotion120Recording replayd')
        self.assertEqual(checker.check_source(repo), [])
        for path, data in [('Recording.xmi', 'PMRecording'),
                           ('Makefile', '\nTWEAK_NAME += ProMotion120Recording\n'),
                           ('src/hidden.inc', 'PMRecordingReplFigFactory'),
                           ('.github/workflows/stale.yml', 'run: otool ProMotion120Recording.dylib')]:
            with self.subTest(path=path):
                target = repo / path
                original = target.read_bytes() if target.exists() else None
                target.write_bytes((original or b'') + data.encode())
                self.assertTrue(checker.check_source(repo))
                if original is None:
                    target.unlink()
                else:
                    target.write_bytes(original)

    def test_deb_payload_variants_and_contamination(self):
        # dpkg-deb is a required test dependency, not a skip/pass substitution.
        self.assertIsNotNone(shutil.which('dpkg-deb'), 'install dpkg (CI runs this after packaging tools)')
        for prefix in ['', 'var/jb/', 'var/jb/.jbroot/']:
            base = prefix + 'Library/MobileSubstrate/DynamicLibraries/'
            clean = {base + 'ProMotion120.dylib': b'HOST FIXTURE, NOT MACH-O',
                     base + 'ProMotion120.plist': plistlib.dumps({'Filter': {'Bundles': ['com.apple.UIKit']}})}
            variants = {'clean': clean,
                        'old-dylib': {**clean, base + 'ProMotion120Recording.dylib': b'old'},
                        'old-filter': {**clean, base + 'ProMotion120Recording.plist': plistlib.dumps({'Filter': {'Executables': ['replayd']}})},
                        'renamed-module': {**clean, base + 'ProMotion120.dylib': b'\0PMRecordingFigFactory\0'},
                        'renamed-binary-filter': {**clean, base + 'ProMotion120.plist': plistlib.dumps({'Filter': {'Executables': ['replayd']}}, fmt=plistlib.FMT_BINARY)},
                        'extra-library': {**clean, base + 'Other.dylib': b'unknown'},
                        'empty': {}}
            for name, payload in variants.items():
                with self.subTest(prefix=prefix, variant=name):
                    deb = self.work / 'fixture.deb'
                    fixture_deb(deb, payload)
                    result = subprocess.run([sys.executable, str(ROOT / 'scripts/verify-no-recording.py'), '--deb', str(deb)], capture_output=True, text=True)
                    self.assertEqual(result.returncode, 0 if name == 'clean' else 1, result.stdout + result.stderr)

    def test_symlink_payload_fails_closed(self):
        payload = self.work / 'payload'
        payload.mkdir()
        (payload / 'ProMotion120.dylib').symlink_to('/does-not-exist')
        self.assertTrue(checker.check_package(payload))


if __name__ == '__main__':
    unittest.main()
