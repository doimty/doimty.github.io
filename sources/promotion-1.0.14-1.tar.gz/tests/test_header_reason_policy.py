#!/usr/bin/env python3
"""Execute production reason helpers/replacements against host Objective-C APIs.

GNUstep/clang on Linux; Xcode Foundation on macOS. Only bundle, clock, CA
objects and original IMPs are fixtures. The ownership predicate, eligibility,
Direct/Banner helpers, range constructor and replacements are extracted intact.
No Python replacement of production logic; no iOS/ARC/PAC or FPS claims.
"""
from pathlib import Path
import itertools
import json
import platform
import re
import shlex
import subprocess
import tempfile
import unittest

from test_float_metadata_scope import function

ROOT = Path(__file__).resolve().parents[1]
ROLES = ('app', 'sb', 'float-host')
ENVIRONMENTS = tuple(itertools.product(ROLES, (False, True), (False, True)))
OWNERS = ('foreign', 'global', 'app')
INPUTS = ('null-zero', 'null-positive', 'array-zero', 'normal', 'one',
          'guard-zero', 'huge-count', 'wide-count')
CAPABILITIES = ('neither', 'single', 'array', 'both')

FIXTURE = r'''
#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#include <assert.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#ifndef __unused
#define __unused __attribute__((unused))
#endif
#ifndef MAP_ANONYMOUS
#define MAP_ANONYMOUS MAP_ANON
#endif
typedef double CFAbsoluteTime;
typedef struct { float minimum, maximum, preferred; } CAFrameRateRange;
static double hostNow = 100.0;
#define CFAbsoluteTimeGetCurrent() hostNow
// Single-threaded dispatch_once is a platform seam, not policy code.
typedef int PMReasonHostOnce;
#define dispatch_once_t PMReasonHostOnce
#undef dispatch_once
#define dispatch_once(token, block) do { if (!*(token)) { *(token)=1; block(); } } while (0)
static NSString *hostBundle;
@interface PMReasonBundle : NSObject
+ (id)mainBundle;
- (NSString *)bundleIdentifier;
@end
@implementation PMReasonBundle
+ (id)mainBundle { static id b; if (!b) b=[PMReasonBundle new]; return b; }
- (NSString *)bundleIdentifier { return hostBundle; }
@end
#define NSBundle PMReasonBundle
static int singleWrites, arrayWrites, rangeWrites, globalApplies;
static BOOL throwSingle, throwArray, throwGlobal;
static unsigned int helperReason;
static NSUInteger helperCount;
static CAFrameRateRange helperRange;
static void recordSingle(unsigned int reason) {
    singleWrites++; helperReason=reason;
    if (throwSingle) [NSException raise:@"single" format:@"setter failed"];
}
static void recordArray(const unsigned int *reasons, NSUInteger count) {
    arrayWrites++; helperCount=count;
    helperReason=(reasons && count) ? reasons[0] : 0;
    if (throwArray) [NSException raise:@"array" format:@"setter failed"];
}
// Four real method tables, rather than lying via respondsToSelector:.
@interface PMReasonNeither : NSObject
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range;
@end
@implementation PMReasonNeither
- (void)setPreferredFrameRateRange:(CAFrameRateRange)range { rangeWrites++; helperRange=range; }
@end
@interface PMReasonSingle : PMReasonNeither
- (void)setHighFrameRateReason:(unsigned int)reason;
@end
@implementation PMReasonSingle
- (void)setHighFrameRateReason:(unsigned int)reason { recordSingle(reason); }
@end
@interface PMReasonArray : PMReasonNeither
- (void)setHighFrameRateReasons:(const unsigned int *)reasons count:(NSUInteger)count;
@end
@implementation PMReasonArray
- (void)setHighFrameRateReasons:(const unsigned int *)reasons count:(NSUInteger)count { recordArray(reasons,count); }
@end
@interface PMReasonBoth : PMReasonSingle
- (void)setHighFrameRateReasons:(const unsigned int *)reasons count:(NSUInteger)count;
@end
@implementation PMReasonBoth
- (void)setHighFrameRateReasons:(const unsigned int *)reasons count:(NSUInteger)count { recordArray(reasons,count); }
@end
static id makeObject(const char *capability) {
    if (!strcmp(capability,"neither")) return [PMReasonNeither new];
    if (!strcmp(capability,"single")) return [PMReasonSingle new];
    if (!strcmp(capability,"array")) return [PMReasonArray new];
    assert(!strcmp(capability,"both")); return [PMReasonBoth new];
}
static void PMGlobalSBApply(NSString *reason) {
    globalApplies++;
    if (throwGlobal) [NSException raise:@"owner" format:@"apply failed"];
}
typedef void (*PMRangeSetterIMP)(id, SEL, CAFrameRateRange);
typedef void (*PMReasonsSetterIMP)(id, SEL, const unsigned int *, NSUInteger);
static PMRangeSetterIMP orig_CADynamicFrameRateSource_setPreferredFrameRateRange;
static PMReasonsSetterIMP orig_CADynamicFrameRateSource_setHighFrameRateReasons_count;
static int originalCalls;
static id receivedSelf;
static SEL receivedSelector;
static const unsigned int *receivedPointer, *guardPointer;
static NSUInteger receivedCount;
static BOOL receivedFirstValid, inspectManagedSingleton;
static unsigned int receivedFirst;
static CAFrameRateRange receivedRange;
static void originalReasons(id obj, SEL sel, const unsigned int *reasons, NSUInteger count) {
    originalCalls++; receivedSelf=obj; receivedSelector=sel;
    receivedPointer=reasons; receivedCount=count;
    // Do NOT walk or read foreign payloads. Only observe a bounded singleton;
    // a PROT_NONE input must never be dereferenced even by this original spy.
    receivedFirstValid=inspectManagedSingleton && reasons && count==1 && reasons!=guardPointer;
    if (receivedFirstValid) receivedFirst=reasons[0];
}
static void originalRange(id obj, SEL sel, CAFrameRateRange range) {
    originalCalls++; receivedSelf=obj; receivedSelector=sel; receivedRange=range;
}
'''

TAIL = r'''
int main(int argc, char **argv) { @autoreleasepool {
    assert(argc==8);
    const char *mode=argv[1], *role=argv[2], *subject=argv[5], *variant=argv[6];
    int flags=atoi(argv[7]);
    hostBundle=!strcmp(role,"sb") ? @"com.apple.springboard" :
        (!strcmp(role,"float-host") ? @"com.be-huge.floating-view" : @"org.example.app");
    PMBannerWindowConfirmed=atoi(argv[3]); PMBannerArmUntil=200.0;
    PMFloatWindowConfirmed=atoi(argv[4]); PMFloatArmUntil=200.0;
    const unsigned int *input=NULL;
    NSUInteger count=0;
    id obj=nil;
    SEL command=NULL;
    BOOL escaped=NO, contentIntact=YES;
    int first=0, repeated=0, early=0, later=0;
    size_t page=(size_t)sysconf(_SC_PAGESIZE);
    void *mapping=MAP_FAILED;
    if (!strcmp(mode,"direct") || !strcmp(mode,"banner")) {
        obj=!strcmp(subject,"nil") ? nil : makeObject(subject);
        throwSingle=!strcmp(variant,"single") || !strcmp(variant,"both");
        throwArray=!strcmp(variant,"array") || !strcmp(variant,"both");
        if (!strcmp(variant,"expired")) PMBannerArmUntil=hostNow;
        @try {
            if (!strcmp(mode,"direct")) PMSetHighFrameRateReasonDirect(obj);
            else PMSetHighFrameRateReasonIfPossible(obj,(flags&1)!=0,(flags&2)!=0);
        } @catch (__unused NSException *e) { escaped=YES; }
    } else if (!strcmp(mode,"banner-guard")) {
        // This is the actual Banner source reapply guard, not a fixture copy.
        throwGlobal=!strcmp(variant,"throw");
        PMApplyDisplayFrameRateSource(@"first"); first=globalApplies;
        throwGlobal=NO;
        PMApplyDisplayFrameRateSource(@"repeat"); repeated=globalApplies;
        hostNow=100.099; PMApplyDisplayFrameRateSource(@"early"); early=globalApplies;
        hostNow=100.101; PMApplyDisplayFrameRateSource(@"later"); later=globalApplies;
    } else {
        obj=[PMReasonBoth new];
        if (!strcmp(subject,"global")) PMGlobalSBDisplaySource=obj;
        else if (!strcmp(subject,"app")) PMAppPersistentFrameRateSource=obj;
        else assert(!strcmp(subject,"foreign"));
        inspectManagedSingleton=strcmp(subject,"foreign")!=0;
        BOOL noOriginal=strstr(mode,"no-orig")!=NULL;
        if (!strncmp(mode,"reasons",7)) {
            // Read-only normal payload ends at a protected page. Guard payloads
            // catch even one speculative read; huge counts are NEVER traversed.
            mapping=mmap(NULL,page*2,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
            assert(mapping!=MAP_FAILED);
            assert(mprotect(mapping,page,PROT_READ|PROT_WRITE)==0);
            unsigned int *normal=(unsigned int *)((char *)mapping+page)-4;
            const unsigned int saved[4]={0U,7U,2U,UINT_MAX};
            memcpy(normal,saved,sizeof(saved));
            assert(mprotect(mapping,page,PROT_READ)==0);
            guardPointer=(const unsigned int *)((char *)mapping+page);
            if (!strcmp(variant,"null-zero")) { input=NULL; count=0; }
            else if (!strcmp(variant,"null-positive")) { input=NULL; count=4; }
            else if (!strcmp(variant,"array-zero")) { input=normal; count=0; }
            else if (!strcmp(variant,"normal")) { input=normal; count=4; }
            else if (!strcmp(variant,"one")) { input=normal+1; count=1; }
            else if (!strcmp(variant,"guard-zero")) { input=guardPointer; count=0; }
            else if (!strcmp(variant,"huge-count")) { input=guardPointer; count=~(NSUInteger)0; }
            else { assert(!strcmp(variant,"wide-count")); input=guardPointer; count=(NSUInteger)UINT_MAX+17ULL; }
            command=NSSelectorFromString(@"setHighFrameRateReasons:count:");
            orig_CADynamicFrameRateSource_setHighFrameRateReasons_count=noOriginal ? NULL : originalReasons;
            repl_CADynamicFrameRateSource_setHighFrameRateReasons_count(obj,command,input,count);
            contentIntact=memcmp(normal,saved,sizeof(saved))==0;
        } else {
            assert(!strncmp(mode,"range",5));
            CAFrameRateRange range={30,60,60};
            if (!strcmp(variant,"zero")) range=(CAFrameRateRange){0,0,0};
            else if (!strcmp(variant,"custom")) range=(CAFrameRateRange){24,144,80};
            else assert(!strcmp(variant,"low"));
            command=NSSelectorFromString(@"setPreferredFrameRateRange:");
            orig_CADynamicFrameRateSource_setPreferredFrameRateRange=noOriginal ? NULL : originalRange;
            repl_CADynamicFrameRateSource_setPreferredFrameRateRange(obj,command,range);
        }
    }
    NSDictionary *result=@{
        @"single":@(singleWrites), @"array":@(arrayWrites),
        @"reason_writes":@(singleWrites+arrayWrites), @"range_writes":@(rangeWrites),
        @"helper_reason":@(helperReason), @"helper_count":@(helperCount), @"escaped":@(escaped),
        @"orig_calls":@(originalCalls), @"same_self":@(receivedSelf==obj),
        @"same_selector":@(receivedSelector==command || (receivedSelector && command && sel_isEqual(receivedSelector,command))),
        @"same_pointer":@(receivedPointer==input), @"same_count":@(receivedCount==count),
        @"count":@(receivedCount), @"first_valid":@(receivedFirstValid), @"first_reason":@(receivedFirst),
        @"content_intact":@(contentIntact),
        @"range":@[@(receivedRange.minimum),@(receivedRange.maximum),@(receivedRange.preferred)],
        @"guard_counts":@[@(first),@(repeated),@(early),@(later)]};
    NSData *data=[NSJSONSerialization dataWithJSONObject:result options:0 error:NULL];
    assert(data); puts([[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] UTF8String]);
    if (mapping!=MAP_FAILED) assert(munmap(mapping,page*2)==0);
    [obj release];
} return 0; }
'''


def read_source(name):
    return (ROOT / 'src' / name).read_text()


def declaration(text, name):
    match = re.search(r'^static [^\n]*\b' + re.escape(name) + r'\s*=[^\n]*;', text, re.M)
    if not match:
        raise ValueError('production declaration not found: ' + name)
    return match.group(0) + '\n'


def integration_source():
    utility = read_source('PMUtility.xm.inc')
    banner = read_source('PMBanner.xm.inc')
    floating = read_source('PMFloat.xm.inc')
    owners = read_source('PMAppPersistent.xm.inc')
    runtime = read_source('PMRuntimeHooks.xm.inc')
    entry = (ROOT / 'Tweak.xmi').read_text()
    target = re.search(r'^#define TARGET_FPS[^\n]*$', entry, re.M)
    if not target:
        raise ValueError('production TARGET_FPS definition not found')
    source = FIXTURE + '\n' + target.group(0) + '\n'
    source += utility[:utility.index('static NSString *PMBundleID')]
    source += declaration(read_source('PMKeepAlive.xm.inc'), 'PMGlobalSBDisplaySource')
    source += declaration(owners, 'PMAppPersistentFrameRateSource')
    for name in ('PMBannerWindowConfirmed', 'PMBannerArmUntil', 'PMBannerLastSourceApplyAt'):
        source += declaration(banner, name)
    for name in ('PMFloatWindowConfirmed', 'PMFloatArmUntil'):
        source += declaration(floating, name)
    for name in ('PMBundleID', 'PMIsTargetProcess',
                 'PMForce120Range', 'PMSetHighFrameRateReasonDirect'):
        source += function(utility, name)
    # Historical source is still usable for negative controls; the shipped
    # candidate must not retain this now-unreferenced helper (see hygiene test).
    if re.search(r'\bPMIsAppProcessEligible\s*\(', utility):
        source += function(utility, 'PMIsAppProcessEligible')
    source += function(owners, 'PMIsManagedSource')
    for name in ('PMBannerIsArmed', 'PMBannerIsEligibleNow',
                 'PMSetHighFrameRateReasonIfPossible', 'PMApplyDisplayFrameRateSource'):
        source += function(banner, name)
    for name in ('PMFloatIsArmed', 'PMFloatIsEligibleNow'):
        source += function(floating, name)
    for name in ('repl_CADynamicFrameRateSource_setPreferredFrameRateRange',
                 'repl_CADynamicFrameRateSource_setHighFrameRateReasons_count'):
        source += function(runtime, name)
    source += TAIL
    source = re.sub(r'(static SEL \w+ = )nil;', r'\1NULL;', source)
    if platform.system() != 'Darwin':
        # Only change Apple's dispatch operation to the GNU runtime's IMP lookup.
        # Keep all branches, setter arguments and exception handlers unchanged.
        for cast, selector in (('PMUIntSetterDyn', 'singleSel'),
                               ('PMReasonsSetterDyn', 'multiSel')):
            source = source.replace('(' + cast + ')objc_msgSend',
                                    '(' + cast + ')objc_msg_lookup(obj, ' + selector + ')')
    return source


def compile_fixture(directory):
    source = directory / 'header_reason_policy.m'
    binary = directory / 'header_reason_policy'
    source.write_text(integration_source())
    checks = ['-std=gnu11', '-fblocks', '-Wall', '-Wextra', '-Werror',
              '-Wno-unused-parameter', '-Wno-unused-function', '-Wno-unused-variable']
    if platform.system() == 'Darwin':
        command = ['xcrun', '--sdk', 'macosx', 'clang', *checks, '-fno-objc-arc',
                   str(source), '-framework', 'Foundation', '-o', str(binary)]
    else:
        flags = shlex.split(subprocess.check_output(['gnustep-config', '--objc-flags'], text=True))
        libs = shlex.split(subprocess.check_output(['gnustep-config', '--base-libs'], text=True))
        include = subprocess.check_output(['gcc', '-print-file-name=include'], text=True).strip()
        command = ['clang', *flags, *checks, '-Wno-cast-function-type-mismatch',
                   '-I' + include, str(source), '-o', str(binary), *libs, '-lBlocksRuntime']
    result = subprocess.run(command, cwd=directory, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError('actual-code reason fixture compile failed:\n' + result.stdout + result.stderr)
    return binary


class HeaderBuildHygieneTests(unittest.TestCase):
    def test_obsolete_app_eligibility_helper_removed(self):
        # Run 37330400392 failed with -Werror,-Wunused-function. Do not mask
        # the target compiler warning or reintroduce its unused definition.
        self.assertNotIn('PMIsAppProcessEligible', read_source('PMUtility.xm.inc'))


class HeaderReasonPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='pm-header-reason-policy-')
        cls.addClassCleanup(cls.temp.cleanup)
        cls.binary = compile_fixture(Path(cls.temp.name))

    def observe(self, mode, role='sb', banner=True, floating=False,
                subject='both', variant='none', flags=2):
        args = [str(self.binary), mode, role, str(int(banner)), str(int(floating)),
                subject, variant, str(flags)]
        result = subprocess.run(args, cwd=self.temp.name, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, ' '.join(args[1:]) + '\n' + result.stdout + result.stderr)
        return json.loads(result.stdout)

    def assert_helper(self, result, capability, eligible=True):
        # Contract assertions, not an executable replacement of production code.
        expected = {'neither': (0, 0), 'single': (1, 0), 'array': (0, 1), 'both': (0, 1)}
        writes = expected[capability] if eligible else (0, 0)
        self.assertFalse(result['escaped'], result)
        self.assertEqual((result['single'], result['array']), writes, result)
        self.assertEqual(result['reason_writes'], sum(writes), result)
        self.assertEqual(result['range_writes'], 0, result)
        if sum(writes):
            self.assertEqual(result['helper_reason'], 1, result)
        if writes[1]:
            self.assertEqual(result['helper_count'], 1, result)

    def assert_original_once(self, result):
        self.assertEqual(result['orig_calls'], 1, result)
        self.assertTrue(result['same_self'], result)
        self.assertTrue(result['same_selector'], result)
        self.assertEqual(result['reason_writes'], 0, result)
        self.assertEqual(result['range_writes'], 0, result)

    def test_direct_four_setter_capabilities(self):
        for capability in CAPABILITIES:
            with self.subTest(capability=capability):
                self.assert_helper(self.observe('direct', subject=capability), capability)

    def test_direct_exceptions_never_fall_back_or_escape(self):
        for capability, failure in itertools.product(CAPABILITIES, ('single', 'array', 'both')):
            with self.subTest(capability=capability, failure=failure):
                self.assert_helper(self.observe('direct', subject=capability, variant=failure), capability)

    def test_direct_nil_is_noop(self):
        self.assert_helper(self.observe('direct', subject='nil'), 'neither')

    def test_banner_delegates_to_direct_instead_of_duplicate_dispatch(self):
        helper = function(read_source('PMBanner.xm.inc'), 'PMSetHighFrameRateReasonIfPossible')
        self.assertRegex(helper, r'\bPMSetHighFrameRateReasonDirect\s*\(\s*obj\s*\)')
        self.assertNotIn('objc_msgSend', helper)

    def test_banner_four_capabilities_for_all_object_kind_flags(self):
        for capability, flags in itertools.product(CAPABILITIES, range(4)):
            with self.subTest(capability=capability, flags=flags):
                self.assert_helper(self.observe('banner', subject=capability, flags=flags), capability)

    def test_banner_exceptions_use_same_one_setter_policy(self):
        for capability, failure in itertools.product(CAPABILITIES, ('single', 'array', 'both')):
            with self.subTest(capability=capability, failure=failure):
                self.assert_helper(self.observe('banner', subject=capability, variant=failure), capability)

    def test_banner_eligibility_guard_for_app_sb_float(self):
        for (role, banner, floating), flags in itertools.product(ENVIRONMENTS, range(4)):
            with self.subTest(role=role, banner=banner, floating=floating, flags=flags):
                result = self.observe('banner', role, banner, floating, flags=flags)
                self.assert_helper(result, 'both', eligible=role == 'sb' and banner)

    def test_banner_nil_is_noop_for_all_object_kind_flags(self):
        for flags in range(4):
            with self.subTest(flags=flags):
                self.assert_helper(self.observe('banner', subject='nil', flags=flags), 'neither')

    def test_banner_expired_arm_is_noop(self):
        for flags in range(4):
            with self.subTest(flags=flags):
                self.assert_helper(self.observe('banner', variant='expired', flags=flags), 'both', eligible=False)

    def test_banner_actual_source_reapply_guard_and_eligibility(self):
        for role, banner, floating in ENVIRONMENTS:
            with self.subTest(role=role, banner=banner, floating=floating):
                result = self.observe('banner-guard', role, banner, floating)
                expected = [1, 1, 1, 2] if role == 'sb' and banner else [0, 0, 0, 0]
                self.assertEqual(result['guard_counts'], expected, result)

    def test_banner_failed_source_apply_does_not_poison_repeat_guard(self):
        result = self.observe('banner-guard', variant='throw')
        self.assertEqual(result['guard_counts'], [1, 2, 2, 3], result)

    def test_foreign_reasons_exact_pointer_count_and_content_passthrough(self):
        for (role, banner, floating), payload in itertools.product(ENVIRONMENTS, INPUTS):
            with self.subTest(role=role, banner=banner, floating=floating, payload=payload):
                result = self.observe('reasons', role, banner, floating, 'foreign', payload)
                self.assert_original_once(result)
                self.assertTrue(result['same_pointer'], result)
                self.assertTrue(result['same_count'], result)
                self.assertTrue(result['content_intact'], result)

    def test_both_managed_owners_always_replace_with_one_reason_one(self):
        for (role, banner, floating), owner, payload in itertools.product(ENVIRONMENTS, OWNERS[1:], INPUTS):
            with self.subTest(role=role, banner=banner, floating=floating, owner=owner, payload=payload):
                result = self.observe('reasons', role, banner, floating, owner, payload)
                self.assert_original_once(result)
                self.assertEqual(result['count'], 1, result)
                self.assertTrue(result['first_valid'], result)
                self.assertEqual(result['first_reason'], 1, result)
                self.assertFalse(result['same_pointer'], result)
                self.assertTrue(result['content_intact'], result)

    def test_reasons_without_original_never_read_input_or_write_setters(self):
        for (role, banner, floating), owner, payload in itertools.product(
                ENVIRONMENTS, OWNERS, ('null-zero', 'huge-count')):
            with self.subTest(role=role, banner=banner, floating=floating, owner=owner, payload=payload):
                result = self.observe('reasons-no-orig', role, banner, floating, owner, payload)
                self.assertEqual(result['orig_calls'], 0, result)
                self.assertEqual(result['reason_writes'], 0, result)
                self.assertEqual(result['range_writes'], 0, result)
                self.assertTrue(result['content_intact'], result)

    def test_foreign_range_policy_unchanged_and_no_reason_writes(self):
        ranges = {'low': [30, 60, 60], 'zero': [0, 0, 0], 'custom': [24, 144, 80]}
        for (role, banner, floating), payload in itertools.product(ENVIRONMENTS, ranges):
            with self.subTest(role=role, banner=banner, floating=floating, payload=payload):
                result = self.observe('range', role, banner, floating, 'foreign', payload)
                self.assert_original_once(result)
                expected = [120, 120, 120] if (role == 'sb' and banner) or floating else ranges[payload]
                self.assertEqual(result['range'], expected, result)

    def test_both_managed_owner_ranges_remain_exact_120_without_reason_writes(self):
        for (role, banner, floating), owner, payload in itertools.product(
                ENVIRONMENTS, OWNERS[1:], ('low', 'zero', 'custom')):
            with self.subTest(role=role, banner=banner, floating=floating, owner=owner, payload=payload):
                result = self.observe('range', role, banner, floating, owner, payload)
                self.assert_original_once(result)
                self.assertEqual(result['range'], [120, 120, 120], result)

    def test_range_without_original_has_no_reason_side_effect(self):
        for (role, banner, floating), owner in itertools.product(ENVIRONMENTS, OWNERS):
            with self.subTest(role=role, banner=banner, floating=floating, owner=owner):
                result = self.observe('range-no-orig', role, banner, floating, owner, 'low')
                self.assertEqual(result['orig_calls'], 0, result)
                self.assertEqual(result['reason_writes'], 0, result)
                self.assertEqual(result['range_writes'], 0, result)


if __name__ == '__main__':
    unittest.main()
