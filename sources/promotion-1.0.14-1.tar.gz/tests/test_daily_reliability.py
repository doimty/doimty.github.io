#!/usr/bin/env python3
"""Run actual production probe/bootstrap/install/owner bodies against host APIs.

Only platform boundaries are fixtures: class/method/symbol availability,
Substrate submission, display evidence, dispatch queue and notification center.
No Python reimplementation of the state machine. Not iOS/ARC/PAC validation.
Requires clang + GNUstep/BlocksRuntime on Linux, Xcode Foundation on macOS.
"""
from pathlib import Path
import platform
import re
import shlex
import subprocess
import tempfile
import unittest
from test_float_metadata_scope import function

ROOT = Path(__file__).resolve().parents[1]

FIXTURE = r'''
#import <Foundation/Foundation.h>
#import <objc/message.h>
#import <objc/runtime.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <Block.h>
#ifndef __unused
#define __unused __attribute__((unused))
#endif
#define TARGET_FPS 120
typedef double CFAbsoluteTime;
typedef double CFTimeInterval;
typedef struct { float minimum, maximum, preferred; } CAFrameRateRange;
static double hostNow = 100.0;
#define CFAbsoluteTimeGetCurrent() hostNow
static BOOL mainThread = YES, springboard, sourceClassReady = YES;
static BOOL rangeReady = YES, reasonsReady = YES, restrictionReady = YES, arbitrationReady = YES, aliasSymbols;
static BOOL displayClassReady = YES, nilDisplay, throwDisplay, throwModes, sourceFails, sourceThrows, linkFails;
static BOOL linkRangeThrows, linkAttachThrows;
static int discardedLinks;
static BOOL reentrant;
static void PMAppEnsurePersistentSource(void);
static void PMGlobalSBApplyForced(NSString *reason);
static BOOL PMInstallDynamicSourceHooks(void);
static void PMInstallQuartzCoreHooks(void);
static id fixtureModes;
static NSInteger hardwareMaximum = 120;
static int hardwareReads, probes, creates, createAttempts, linkCreates, runLoopAdds, coreCalls, bannerInstalls, menuInstalls;
static int rangeHooks, reasonsHooks, restrictionHooks, arbitrationHooks, symbolReads, rangeWrites, reasonWrites;
static NSUInteger lastReasonCount;
static unsigned int lastReason;
static CAFrameRateRange lastRange;
static unsigned dispatches, maximumPending;
static void (^tasks[64])(void);
static unsigned pending;
static void (^observers[8])(NSNotification *);
static unsigned observerCount;

@interface PMHostThread : NSObject
+ (BOOL)isMainThread;
@end
@implementation PMHostThread
+ (BOOL)isMainThread { return mainThread; }
@end
#define NSThread PMHostThread
static void enqueue(void (^task)(void)) {
    assert(pending < 64); tasks[pending++] = Block_copy(task); dispatches++;
    if (pending > maximumPending) maximumPending = pending;
}
static void tick(void) {
    assert(mainThread && pending); void (^task)(void) = tasks[0];
    for (unsigned i=1;i<pending;i++) tasks[i-1]=tasks[i];
    pending--; hostNow += .5; task(); Block_release(task);
}
static void drain(void) { unsigned n=0; while(pending) { assert(n++ < 32); tick(); } }
#define dispatch_async(queue, block) enqueue(block)
#define dispatch_after(time, queue, block) enqueue(block)
typedef int PMHostOnceToken;
#define dispatch_once_t PMHostOnceToken
#undef dispatch_once
#define dispatch_once(token, block) do { if (!*(token)) { *(token)=1; block(); } } while(0)
@interface PMHostCenter : NSObject
+ (id)defaultCenter;
- (id)addObserverForName:(NSString *)name object:(id)object queue:(id)queue usingBlock:(void (^)(NSNotification *))block;
@end
@implementation PMHostCenter
+ (id)defaultCenter { static id c; if(!c)c=[PMHostCenter new]; return c; }
- (id)addObserverForName:(NSString *)name object:(id)object queue:(id)queue usingBlock:(void (^)(NSNotification *))block {
    assert(observerCount < 8); observers[observerCount++] = Block_copy(block); return self;
}
@end
#define NSNotificationCenter PMHostCenter
#define UIApplicationDidFinishLaunchingNotification @"launch"
#define UIApplicationWillEnterForegroundNotification @"foreground"
#define UIApplicationDidBecomeActiveNotification @"active"
static void active(void) { assert(observerCount==3); observers[2](nil); }

@interface PMHostBundle : NSObject
+ (id)mainBundle;
- (NSString *)bundleIdentifier;
@end
@implementation PMHostBundle
+ (id)mainBundle { static id b; if(!b)b=[PMHostBundle new]; return b; }
- (NSString *)bundleIdentifier { return springboard ? @"com.apple.springboard" : @"org.example.app"; }
@end
#define NSBundle PMHostBundle
@interface UIScreen : NSObject
+ (id)mainScreen;
- (NSInteger)maximumFramesPerSecond;
@end
@implementation UIScreen
+ (id)mainScreen { static id s; if(!s)s=[UIScreen new]; return s; }
- (NSInteger)maximumFramesPerSecond { hardwareReads++; assert(coreCalls==0); return hardwareMaximum; }
@end
@interface CADisplay : NSObject
+ (id)mainDisplay;
- (id)availableModes;
@end
@implementation CADisplay
+ (id)mainDisplay {
    probes++; if(throwDisplay) [NSException raise:@"display" format:@"not ready"];
    if(nilDisplay)return nil; static id d; if(!d)d=[CADisplay new]; return d;
}
- (id)availableModes {
    if(throwModes) [NSException raise:@"modes" format:@"not ready"];
    return fixtureModes;
}
@end
@interface PMThrowingMode : NSObject @end
@implementation PMThrowingMode
- (id)valueForKey:(NSString *)key { [NSException raise:@"rate" format:@"not ready"]; return nil; }
@end
@interface CADynamicFrameRateSource : NSObject
- (id)initWithDisplay:(id)display;
- (void)setPreferredFrameRateRange:(CAFrameRateRange)r;
- (void)setHighFrameRateReason:(unsigned int)r;
- (void)setHighFrameRateReasons:(const unsigned int *)r count:(NSUInteger)n;
@end
@implementation CADynamicFrameRateSource
- (id)initWithDisplay:(id)display {
    assert(mainThread && rangeHooks==1 && reasonsHooks==1); createAttempts++;
    if(sourceThrows) [NSException raise:@"source" format:@"not ready"];
    if(sourceFails) { [self release]; return nil; }
    if(reentrant) { PMAppEnsurePersistentSource(); PMGlobalSBApplyForced(@"reentrant init"); }
    creates++; return [super init];
}
- (void)setPreferredFrameRateRange:(CAFrameRateRange)r { rangeWrites++; lastRange=r; }
- (void)setHighFrameRateReason:(unsigned int)r { reasonWrites++; }
- (void)setHighFrameRateReasons:(const unsigned int *)r count:(NSUInteger)n { reasonWrites++; lastReasonCount=n; lastReason=r&&n ? r[0] : 0; }
@end
#define CACurrentMediaTime() hostNow
@interface CADisplayLink : NSObject
- (double)timestamp;
- (double)duration;
- (double)targetTimestamp;
+ (id)displayLinkWithTarget:(id)target selector:(SEL)sel;
- (void)setPreferredFrameRateRange:(CAFrameRateRange)r;
- (void)setPreferredFramesPerSecond:(NSInteger)fps;
- (void)addToRunLoop:(id)loop forMode:(id)mode;
- (void)invalidate;
@end
@implementation CADisplayLink
- (double)timestamp { return hostNow; }
- (double)duration { return 1.0/120.0; }
- (double)targetTimestamp { return hostNow + 1.0/120.0; }
+ (id)displayLinkWithTarget:(id)target selector:(SEL)sel { assert(mainThread); if(linkFails)return nil; linkCreates++; return [CADisplayLink new]; }
- (void)setPreferredFrameRateRange:(CAFrameRateRange)r { if(linkRangeThrows) [NSException raise:@"link range" format:@"not ready"]; }
- (void)setPreferredFramesPerSecond:(NSInteger)fps {}
- (void)addToRunLoop:(id)loop forMode:(id)mode { if(linkAttachThrows) [NSException raise:@"link attach" format:@"not ready"]; runLoopAdds++; }
- (void)invalidate { discardedLinks++; }
@end
@interface UIScrollView : NSObject
- (BOOL)dragging;
- (BOOL)tracking;
- (BOOL)decelerating;
@end
@implementation UIScrollView
- (BOOL)dragging { return NO; }
- (BOOL)tracking { return NO; }
- (BOOL)decelerating { return NO; }
@end
static Class hostClass(NSString *name) {
    if([name isEqual:@"CADisplay"]&&!displayClassReady) return Nil;
    if([name isEqual:@"CADynamicFrameRateSource"]&&!sourceClassReady) return Nil;
    return NSClassFromString(name);
}
static Class hostObjCClass(const char *name) { return hostClass([NSString stringWithUTF8String:name]); }
static Method hostMethod(Class cls, SEL selector) {
    if(sel_isEqual(selector,@selector(setPreferredFrameRateRange:))&&!rangeReady)return NULL;
    if(sel_isEqual(selector,@selector(setHighFrameRateReasons:count:))&&!reasonsReady)return NULL;
    return class_getInstanceMethod(cls,selector);
}
static void MSHookMessageEx(Class cls, SEL sel, IMP replacement, IMP *original) {
    assert(mainThread);
    if(sel_isEqual(sel,@selector(setPreferredFrameRateRange:)))assert(++rangeHooks==1);
    else assert(++reasonsHooks==1);
    *original=class_getMethodImplementation(cls,sel);
    if(reentrant) assert(!PMInstallDynamicSourceHooks());
}
#define NSClassFromString hostClass
#define objc_getClass hostObjCClass
#define class_getInstanceMethod hostMethod
static void MSHookFunction(void *address, void *replacement, void **original) {
    assert(mainThread); if(address==(void *)1)assert(++restrictionHooks==1); else assert(++arbitrationHooks==1);
    *original=address;
    if(reentrant) PMInstallQuartzCoreHooks();
}
static void *PMQuartzCoreFindSymbol(const char *name) {
    assert(mainThread); symbolReads++;
    if(strstr(name,"Restriction"))return restrictionReady ? (void *)1 : NULL;
    return arbitrationReady ? (aliasSymbols ? (void *)1 : (void *)2) : NULL;
}
static void PMInstallHooks(void) { assert(++bannerInstalls==1); }
static void PMHookContextMenuInteractionIfAvailable(void) { menuInstalls++; }
static void PMHookEditMenuInteractionIfAvailable(void) { menuInstalls++; }
static BOOL PMBannerIsEligibleNow(void) { return NO; }
static BOOL PMFloatIsEligibleNow(void) { return NO; }
static void PMSetHighFrameRateReasonIfPossible(id obj, BOOL a, BOOL b) {}
static BOOL PMInstallDynamicSourceHooks(void);
static void PMRequestSourceRecoveryOnMain(void);
'''

TAIL = r'''
static void readyModes(void) { fixtureModes=@[@{@"refreshRate":@120}]; }
static void assertInstalled(void) {
    assert(coreCalls==1 && rangeHooks==1 && reasonsHooks==1 && creates==1);
    assert(restrictionHooks==1 && arbitrationHooks==1);
    assert(linkCreates-discardedLinks==(springboard?1:0));
    assert(runLoopAdds==(springboard?1:0));
    assert(observerCount==3);
    assert(bannerInstalls==(springboard?1:0));
    assert(menuInstalls==(springboard?2:0));
}
int main(int argc, char **argv) { @autoreleasepool {
    assert(argc==3); const char *scenario=argv[1]; springboard=strcmp(argv[2],"sb")==0;
    readyModes();
    if(strncmp(scenario,"probe-",6)==0) {
        PMCapability expected=PMCapabilityUnknown;
        if(!strcmp(scenario,"probe-nil-class")) displayClassReady=NO;
        else if(!strcmp(scenario,"probe-nil-display")) nilDisplay=YES;
        else if(!strcmp(scenario,"probe-display-exception")) throwDisplay=YES;
        else if(!strcmp(scenario,"probe-modes-exception")) throwModes=YES;
        else if(!strcmp(scenario,"probe-nil-modes")) fixtureModes=nil;
        else if(!strcmp(scenario,"probe-empty")) fixtureModes=@[];
        else if(!strcmp(scenario,"probe-non-array")) fixtureModes=@"120";
        else if(!strcmp(scenario,"probe-all-exceptions")) fixtureModes=@[[PMThrowingMode new],[PMThrowingMode new]];
        else if(!strcmp(scenario,"probe-invalid-values")) fixtureModes=@[@{@"refreshRate":@"120"},@{@"refreshRate":[NSNull null]},@{@"refreshRate":@(NAN)},@{@"refreshRate":@(INFINITY)},@{@"refreshRate":@0},@{@"refreshRate":@(-1)}];
        else if(!strcmp(scenario,"probe-partial-invalid")) { fixtureModes=@[@{@"refreshRate":@60},[PMThrowingMode new]]; hardwareMaximum=60; }
        else if(!strcmp(scenario,"probe-incomplete-60")) fixtureModes=@[@{@"refreshRate":@60}];
        else if(!strcmp(scenario,"probe-120")) expected=PMCapabilitySupported;
        else if(!strcmp(scenario,"probe-partial-120")) { fixtureModes=@[[PMThrowingMode new],@{@"refreshRate":@120}]; expected=PMCapabilitySupported; }
        else if(!strcmp(scenario,"probe-confirmed-60")) { fixtureModes=@[@{@"refreshRate":@60}]; hardwareMaximum=60; expected=PMCapabilityUnsupported; }
        else if(!strcmp(scenario,"probe-negative-recovery")) { fixtureModes=@[@{@"refreshRate":@60}]; hardwareMaximum=60; assert(PMRefreshDeviceCapability()==PMCapabilityUnsupported); readyModes(); expected=PMCapabilitySupported; }
        else if(!strcmp(scenario,"probe-off-main")) mainThread=NO;
        else assert(0);
        assert(PMRefreshDeviceCapability()==expected);
        if(expected==PMCapabilitySupported) {
            int reads=hardwareReads, oldProbes=probes; fixtureModes=nil;
            assert(PMRefreshDeviceCapability()==PMCapabilitySupported);
            assert(hardwareReads==reads && probes==oldProbes);
            assert(PMDeviceSupports120Hz());
        } else assert(!PMDeviceSupports120Hz());
        if(!mainThread) assert(probes==0 && hardwareReads==0);
        puts("PASS probe"); return 0;
    }
    if(!strcmp(scenario,"initial-unknown")) fixtureModes=nil;
    else if(!strcmp(scenario,"late-class") || !strcmp(scenario,"ui-late-class")) sourceClassReady=NO;
    else if(!strcmp(scenario,"reentrant")) reentrant=YES;
    else if(!strcmp(scenario,"partial-range")) reasonsReady=NO;
    else if(!strcmp(scenario,"partial-reasons")) rangeReady=NO;
    else if(!strcmp(scenario,"nil-source")) sourceFails=YES;
    else if(!strcmp(scenario,"throw-source")) sourceThrows=YES;
    else if(!strcmp(scenario,"nil-link")) linkFails=YES;
    else if(!strcmp(scenario,"link-range-exception")) linkRangeThrows=YES;
    else if(!strcmp(scenario,"link-attach-exception")) linkAttachThrows=YES;
    else if(!strcmp(scenario,"late-symbols")) restrictionReady=arbitrationReady=NO;
    else if(!strcmp(scenario,"partial-quartz")) arbitrationReady=NO;
    else if(!strcmp(scenario,"alias-quartz")) aliasSymbols=YES;
    else if(!strcmp(scenario,"confirmed-unsupported")) { fixtureModes=@[@{@"refreshRate":@60}]; hardwareMaximum=60; }
    else assert(!strcmp(scenario,"normal") || !strcmp(scenario,"off-main"));

    mainThread=NO; PMHostConstructor(); assert(pending==1 && coreCalls==0 && observerCount==0);
    mainThread=YES; tick(); assert(observerCount==3);
    PMBootstrapRegisterObservers(); assert(observerCount==3);
    if(pending) {
        unsigned d=dispatches, a=PMBootstrapBudget.attempts;
        for(int i=0;i<100;i++)active();
        assert(dispatches==d && PMBootstrapBudget.attempts==a);
    }
    drain(); assert(pending==0 && maximumPending<=1);
    assert(PMBootstrapBudget.attempts<=PM_RECOVERY_MAX_ATTEMPTS);
    if(!strcmp(scenario,"initial-unknown")) assert(coreCalls==0 && creates==0 && PMBootstrapBudget.attempts==9);
    if(!strcmp(scenario,"confirmed-unsupported")) assert(coreCalls==0 && PMBootstrapBudget.attempts==1);
    if(!strcmp(scenario,"late-class")) assert(rangeHooks==0 && reasonsHooks==0 && createAttempts==0);
    if(!strcmp(scenario,"partial-range")) assert(rangeHooks==1 && reasonsHooks==0 && createAttempts==0);
    if(!strcmp(scenario,"partial-reasons")) assert(rangeHooks==0 && reasonsHooks==1 && createAttempts==0);
    if(!strcmp(scenario,"partial-quartz")) assert(restrictionHooks==1 && arbitrationHooks==0);
    if(!strcmp(scenario,"alias-quartz")) assert(restrictionHooks==1 && arbitrationHooks==0);
    if(sourceFails||sourceThrows) assert(creates==0 && createAttempts==9);
    if(springboard&&linkFails) assert(linkCreates==0);
    if(springboard&&(linkRangeThrows||linkAttachThrows)) {
        assert(PMSBKeepAliveLink==nil && PMSBKeepAliveTargetInstance==nil);
        assert(discardedLinks==9 && PMBootstrapBudget.attempts==9);
    }
    // With no event, the queue stays empty: no self-renewing timer/busy poll.
    unsigned idleDispatches=dispatches; assert(pending==0 && dispatches==idleDispatches);

    readyModes(); sourceClassReady=rangeReady=reasonsReady=restrictionReady=arbitrationReady=YES;
    sourceFails=sourceThrows=linkFails=linkRangeThrows=linkAttachThrows=aliasSymbols=NO;
    // Either the normal UI owner path or a lifecycle event must recover.
    if(!strcmp(scenario,"ui-late-class")) {
        if(springboard) PMGlobalSBApplyForced(@"late UI"); else PMAppEnsurePersistentSource();
    } else active();
    drain(); assertInstalled(); assert(pending==0);
    int lookups=symbolReads;
    for(int i=0;i<100;i++) { active(); PMAppEnsurePersistentSource(); PMGlobalSBSetup(); }
    drain(); assertInstalled(); assert(symbolReads==lookups && pending==0);
    if(!strcmp(scenario,"off-main")) {
        int writes=rangeWrites; mainThread=NO;
        for(int i=0;i<100;i++) {
            PMAppRefreshPersistentSource(); PMGlobalSBApplyForced(@"test");
            assert(!PMInstallDynamicSourceHooks()); PMInstallQuartzCoreHooks();
        }
        assert(pending==1 && rangeWrites==writes && symbolReads==lookups);
        mainThread=YES; drain(); assertInstalled(); assert(rangeWrites>writes);
    }
    // Execute the actual replacement: non-managed clears remain transparent.
    id ordinary=[NSObject new];
    repl_CADynamicFrameRateSource_setHighFrameRateReasons_count(ordinary,NULL,NULL,0);
    assert(lastReasonCount==0);
    id managed=springboard ? PMGlobalSBDisplaySource : PMAppPersistentFrameRateSource;
    repl_CADynamicFrameRateSource_setHighFrameRateReasons_count(managed,NULL,NULL,0);
    assert(lastReasonCount==1 && lastReason==1);
    CAFrameRateRange low={30,60,60};
    repl_CADynamicFrameRateSource_setPreferredFrameRateRange(ordinary,NULL,low);
    assert(lastRange.maximum==60); // C2 is deliberately NOT implemented.
    repl_CADynamicFrameRateSource_setPreferredFrameRateRange(managed,NULL,low);
    assert(lastRange.minimum==120 && lastRange.maximum==120 && lastRange.preferred==120);
    printf("PASS %s %s attempts=%u maxPending=%u creates=%d\n",scenario,argv[2],PMBootstrapBudget.attempts,maximumPending,creates);
} return 0; }
'''


def integration_source():
    def read(name):
        return (ROOT / 'src' / name).read_text()
    utility = read('PMUtility.xm.inc')
    quartz = read('PMQuartzCoreHooks.xm.inc')
    quartz = quartz.replace(function(quartz, 'PMQuartzCoreFindSymbol'), '')
    source = FIXTURE + utility + quartz + read('PMKeepAlive.xm.inc') + read('PMAppPersistent.xm.inc')
    source += r'''
typedef void (*PMRangeSetterIMP)(id, SEL, CAFrameRateRange);
typedef void (*PMReasonsSetterIMP)(id, SEL, const unsigned int *, NSUInteger);
static PMRangeSetterIMP orig_CADynamicFrameRateSource_setPreferredFrameRateRange;
static PMReasonsSetterIMP orig_CADynamicFrameRateSource_setHighFrameRateReasons_count;
'''
    runtime = read('PMRuntimeHooks.xm.inc')
    for name in ['PMInstallHookIfExists',
                 'repl_CADynamicFrameRateSource_setPreferredFrameRateRange',
                 'repl_CADynamicFrameRateSource_setHighFrameRateReasons_count',
                 'PMInstallDynamicSourceHooks']:
        source += function(runtime, name)
    source += read('PMBootstrap.xm.inc').replace('%ctor {', 'static void PMHostConstructor(void) {').replace('%init;', 'coreCalls++;')
    source += TAIL
    source = re.sub(r'(static SEL \w+ = )nil;', r'\1NULL;', source)
    if platform.system() != 'Darwin':
        for cast, receiver, selector in [('PMUIntSetterDyn', 'obj', 'singleSel'),
                                         ('PMReasonsSetterDyn', 'obj', 'multiSel'),
                                         ('PMRangeSetterDyn', 'obj', 'sel'),
                                         ('PMInitFn', 'allocd', 'initS'),
                                         ('PMInitWithDisplayFn', 'allocated', 'initSel')]:
            source = source.replace('(' + cast + ')objc_msgSend', '(' + cast + ')objc_msg_lookup(' + receiver + ', ' + selector + ')')
    return source


def compile_fixture(directory):
    source = directory / 'daily_reliability.m'
    binary = directory / 'daily_reliability'
    source.write_text(integration_source())
    checks = ['-I' + str(ROOT / 'src'), '-std=gnu11', '-fblocks', '-Wall', '-Wextra', '-Werror',
              '-Wno-unused-parameter', '-Wno-unused-function', '-Wno-unused-variable']
    if platform.system() == 'Darwin':
        command = ['xcrun', '--sdk', 'macosx', 'clang', *checks, '-fno-objc-arc', str(source), '-framework', 'Foundation', '-o', str(binary)]
    else:
        flags = shlex.split(subprocess.check_output(['gnustep-config', '--objc-flags'], text=True))
        libs = shlex.split(subprocess.check_output(['gnustep-config', '--base-libs'], text=True))
        include = subprocess.check_output(['gcc', '-print-file-name=include'], text=True).strip()
        # GNU IMP is generically typed; keep this host-only cast warning separate from target ABI validation.
        command = ['clang', *flags, *checks, '-Wno-cast-function-type-mismatch', '-I' + include, str(source), '-o', str(binary), *libs, '-lBlocksRuntime']
    result = subprocess.run(command, cwd=directory, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError('actual-code host compile failed:\n' + result.stdout + result.stderr)
    return binary


class RecoveryBudgetTests(unittest.TestCase):
    def test_production_c_budget_and_evidence(self):
        # Runs even when host Foundation is unavailable; includes the SAME header
        # used by the production Objective-C startup, not a translated model.
        with tempfile.TemporaryDirectory(prefix='pm-recovery-budget-') as name:
            work = Path(name)
            source = work / 'budget.c'
            source.write_text(r'''
#include "PMReliability.h"
#include <assert.h>
int main(void) {
    PMRecoveryBudget s={0};
    assert(PMRecoveryBegin(&s,true));
    assert(!PMRecoveryBegin(&s,true)); // reentrant event
    for(unsigned i=1;i<=PM_RECOVERY_MAX_ATTEMPTS;i++) {
        assert(s.attempts==i);
        bool queued=PMRecoveryEnd(&s,true);
        if(i==PM_RECOVERY_MAX_ATTEMPTS) { assert(!queued); break; }
        for(int j=0;j<100;j++)assert(!PMRecoveryBegin(&s,true));
        assert(s.pending && s.attempts==i);
        s.pending=false;
        assert(PMRecoveryBegin(&s,false));
    }
    assert(!s.pending && !PMRecoveryBegin(&s,false));
    assert(PMRecoveryBegin(&s,true) && s.attempts==1);
    assert(!PMRecoveryEnd(&s,false));
    PMModeEvidence e={0};
    assert(PMModeEvidenceResolve(e,60)==PMCapabilityUnknown);
    PMModeEvidenceAdd(&e,false,120);
    PMModeEvidenceAdd(&e,true,NAN);
    assert(PMModeEvidenceResolve(e,60)==PMCapabilityUnknown);
    PMModeEvidenceAdd(&e,true,120);
    assert(PMModeEvidenceResolve(e,60)==PMCapabilitySupported);
    e=(PMModeEvidence){0}; PMModeEvidenceAdd(&e,true,60);
    assert(PMModeEvidenceResolve(e,120)==PMCapabilityUnknown);
    assert(PMModeEvidenceResolve(e,0)==PMCapabilityUnknown);
    assert(PMModeEvidenceResolve(e,60)==PMCapabilityUnsupported);
    return 0;
}
''')
            compiler = ['xcrun', 'clang'] if platform.system() == 'Darwin' else ['cc']
            subprocess.run([*compiler, '-std=c11', '-Wall', '-Wextra', '-Werror', '-I' + str(ROOT / 'src'), str(source), '-o', str(work / 'budget')], check=True)
            subprocess.run([str(work / 'budget')], check=True, timeout=15)


class DailyReliabilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='pm-daily-reliability-')
        cls.addClassCleanup(cls.temp.cleanup)
        cls.binary = compile_fixture(Path(cls.temp.name))

    def run_scenario(self, scenario, role='app'):
        result = subprocess.run([str(self.binary), scenario, role], capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('PASS', result.stdout)

    def test_probe_states_and_exceptions(self):
        for case in ['nil-class', 'nil-display', 'display-exception', 'modes-exception', 'nil-modes', 'empty', 'non-array',
                     'all-exceptions', 'invalid-values', 'partial-invalid', 'incomplete-60', '120', 'partial-120',
                     'confirmed-60', 'negative-recovery', 'off-main']:
            with self.subTest(case=case):
                self.run_scenario('probe-' + case)

    def test_startup_recovery_idempotence_and_cleanup(self):
        for role in ['app', 'sb']:
            for case in ['normal', 'reentrant', 'initial-unknown', 'confirmed-unsupported', 'late-class', 'ui-late-class', 'partial-range', 'partial-reasons',
                         'nil-source', 'throw-source', 'nil-link', 'link-range-exception', 'link-attach-exception', 'late-symbols', 'partial-quartz', 'alias-quartz', 'off-main']:
                with self.subTest(role=role, case=case):
                    self.run_scenario(case, role)


if __name__ == '__main__':
    unittest.main()
