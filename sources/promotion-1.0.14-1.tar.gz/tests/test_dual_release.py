#!/usr/bin/env python3
"""Host/real-deb fixtures for release packaging, never an iOS execution test."""
from pathlib import Path, PurePosixPath
import hashlib
import importlib.util
import io
import json
import os
import shutil
import struct
import subprocess
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    import sys
    sys.path.insert(0, str(ROOT / 'scripts'))
    spec.loader.exec_module(module)
    return module


checker = load('package_checker', ROOT / 'scripts/verify-release-package.py')
freeze = load('source_freeze', ROOT / 'scripts/verify-release-source.py')
meta = checker.metadata


def dylib_command(command, value):
    header = 12 if command == 0x8000001c else 24
    length = (header + len(value.encode()) + 1 + 7) // 8 * 8
    return struct.pack('<III', command, length, header) + bytes(header - 12) + value.encode() + bytes(length - header - len(value.encode()))


def signed_slice(scheme, arch='arm64e', minimum=0xf0000, sdk=0x110500, dependency=None):
    """Structurally signed synthetic Mach-O; no native code is executed."""
    ident = b'ProMotion120\0'
    hash_off, sig_off = 44 + len(ident), 1024
    sig_size = 20 + hash_off + 32
    install_name = '@rpath/ProMotion120.dylib' if scheme == 'rootless' else '@loader_path/.jbroot/Library/MobileSubstrate/DynamicLibraries/ProMotion120.dylib'
    substrate = '@rpath/CydiaSubstrate.framework/CydiaSubstrate' if scheme == 'rootless' else '@loader_path/.jbroot/usr/lib/libsubstrate.dylib'
    commands = [dylib_command(0xd, install_name), dylib_command(0xc, dependency or substrate),
                struct.pack('<6I', 0x32, 24, 2, minimum, sdk, 0),
                struct.pack('<4I', 0x1d, 16, sig_off, sig_size)]
    if scheme == 'rootless':
        commands.append(dylib_command(0x8000001c, '/var/jb/usr/lib'))
        commands.append(dylib_command(0x8000001c, '/var/jb/Library/Frameworks'))
    header = struct.pack('<8I', 0xfeedfacf, 0x100000c, 0x80000002 if arch == 'arm64e' else 0,
                         6, len(commands), sum(map(len, commands)), 0, 0)
    code = (header + b''.join(commands)).ljust(sig_off, b'\0')
    cd = struct.pack('>9I4BI', 0xfade0c02, hash_off + 32, 0x20100, 2, hash_off, 44,
                     0, 1, sig_off, 32, 2, 0, 12, 0) + ident + hashlib.sha256(code).digest()
    superblob = struct.pack('>5I', 0xfade0cc0, sig_size, 1, 0, 20) + cd
    return code + superblob


def fat(slices):
    headers, chunks, offset = [], [], 4096
    for cpu, subtype, data in slices:
        headers.append(struct.pack('>5I', cpu, subtype, offset, len(data), 12))
        chunks.append((offset, data))
        offset = (offset + len(data) + 4095) // 4096 * 4096
    result = bytearray(struct.pack('>II', 0xcafebabe, len(slices)) + b''.join(headers))
    for offset, data in chunks:
        result.extend(bytes(offset - len(result)))
        result.extend(data)
    return bytes(result)


def binary(scheme):
    if scheme == 'roothide':
        return signed_slice(scheme)
    return fat([(0x100000c, 0, signed_slice(scheme, 'arm64')),
                (0x100000c, 0x80000002, signed_slice(scheme))])


def fixture(scheme):
    fields = meta.parse_control((ROOT / 'control').read_text())
    fields['Architecture'] = 'iphoneos-arm64' if scheme == 'rootless' else 'iphoneos-arm64e'
    fields['Installed-Size'] = '20'
    if scheme == 'roothide':
        fields['Tag'] = 'supports::roothide'
    base = ('var/jb/' if scheme == 'rootless' else '') + 'Library/MobileSubstrate/DynamicLibraries/'
    payload = {base + 'ProMotion120.dylib': {'data': binary(scheme), 'mode': 0o755},
               base + 'ProMotion120.plist': {'data': (ROOT / 'ProMotion120.plist').read_bytes(), 'mode': 0o644}}
    return fields, payload


def tar_bytes(entries, owner=0, duplicates=False):
    out = io.BytesIO()
    with tarfile.open(fileobj=out, mode='w:gz') as archive:
        directories = {'.'} | {str(parent) for name in entries for parent in PurePosixPath(name).parents}
        for name in sorted(directories):
            entry = tarfile.TarInfo(name)
            entry.type, entry.mode, entry.uid, entry.gid = tarfile.DIRTYPE, 0o755, owner, owner
            archive.addfile(entry)
        for name, record in entries.items():
            entry = tarfile.TarInfo(name)
            entry.mode, entry.uid, entry.gid = record['mode'], owner, owner
            entry.type = record.get('type', tarfile.REGTYPE)
            entry.linkname = record.get('linkname', '')
            content = record['data'] if entry.isfile() else b''
            entry.size = len(content)
            archive.addfile(entry, io.BytesIO(content))
            if duplicates:
                archive.addfile(entry, io.BytesIO(content))
    return out.getvalue()


def deb(path, fields, payload, owner=0, duplicates=False, control_mode=0o644):
    control = ''.join(k + ': ' + v + '\n' for k, v in fields.items()).encode()
    members = {'debian-binary': b'2.0\n',
               'control.tar.gz': tar_bytes({'control': {'data': control, 'mode': control_mode}}, owner),
               'data.tar.gz': tar_bytes(payload, owner, duplicates)}
    result = bytearray(b'!<arch>\n')
    for name, data in members.items():
        result.extend(f'{name + "/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(data):<10}`\n'.encode())
        result.extend(data)
        if len(data) % 2:
            result.extend(b'\n')
    path.write_bytes(result)


class DualReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='pm-dual-release-')
        self.addCleanup(self.temp.cleanup)
        self.work = Path(self.temp.name)

    def test_positive_real_deb_and_repack_both_schemes(self):
        for scheme in ('rootless', 'roothide'):
            with self.subTest(scheme=scheme):
                fields, payload = fixture(scheme)
                path = self.work / (scheme + '.deb')
                deb(path, fields, payload)
                self.assertTrue(checker.verify(path, scheme)['numeric_root_checked'])
                before = checker.snapshot(checker.records(path, '--fsys-tarfile'))
                deb(path, fields, payload, owner=501)
                with self.assertRaises(ValueError):
                    checker.verify(path, scheme)
                report = checker.canonicalize(path, scheme)
                self.assertTrue(report['repack_bytes_types_modes_unchanged'])
                self.assertEqual(before, checker.snapshot(checker.records(path, '--fsys-tarfile')))
                self.assertEqual(report['architecture'], fields['Architecture'])

    def test_metadata_negatives_both_schemes(self):
        for scheme in ('rootless', 'roothide'):
            for key, value in [('Version', '1.0.13-2+hdr1'), ('Architecture', 'all'),
                               ('Depends', 'mobilesubstrate'), ('Package', 'com.other'),
                               ('Conflicts', ''), ('Tag', 'supports::wrong')]:
                with self.subTest(scheme=scheme, key=key):
                    fields, payload = fixture(scheme)
                    fields[key] = value
                    path = self.work / 'bad.deb'
                    deb(path, fields, payload)
                    with self.assertRaises(ValueError):
                        checker.verify(path, scheme)
            fields, payload = fixture(scheme)
            if scheme == 'rootless':
                fields['Tag'] = 'supports::roothide'
            else:
                del fields['Tag']
            deb(self.work / 'bad.deb', fields, payload)
            with self.assertRaises(ValueError):
                checker.verify(self.work / 'bad.deb', scheme)

    def test_payload_negatives_both_schemes(self):
        for scheme in ('rootless', 'roothide'):
            for problem in ('prefix', 'extra', 'link', 'setuid', 'filter', 'signature', 'slice', 'duplicate', 'traversal'):
                with self.subTest(scheme=scheme, problem=problem):
                    fields, payload = fixture(scheme)
                    library = next(n for n in payload if n.endswith('.dylib'))
                    filter_name = next(n for n in payload if n.endswith('.plist'))
                    if problem == 'prefix':
                        payload = {'wrong/' + n: r for n, r in payload.items()}
                    elif problem == 'extra':
                        payload['extra.dylib'] = {'data': b'other', 'mode': 0o755}
                    elif problem == 'link':
                        payload[library].update(type=tarfile.SYMTYPE, linkname='/usr/lib/foreign')
                    elif problem == 'setuid':
                        payload[library]['mode'] = 0o4755
                    elif problem == 'filter':
                        payload[filter_name]['data'] = b'not a plist'
                    elif problem == 'signature':
                        raw = bytearray(payload[library]['data'])
                        raw[(4096 if scheme == 'rootless' else 0) + 600] ^= 1
                        payload[library]['data'] = bytes(raw)
                    elif problem == 'slice':
                        payload[library]['data'] = signed_slice(scheme, 'arm64' if scheme == 'roothide' else 'arm64e')
                    elif problem == 'traversal':
                        payload['../outside'] = {'data': b'foreign', 'mode': 0o644}
                    path = self.work / 'bad.deb'
                    deb(path, fields, payload, duplicates=problem == 'duplicate')
                    with self.assertRaises((ValueError, AssertionError, KeyError, struct.error)):
                        checker.verify(path, scheme)
                    with self.assertRaises((ValueError, AssertionError, KeyError, struct.error)):
                        checker.canonicalize(path, scheme)

    def test_minimum_sdk_and_signature_guards_have_effective_mutations(self):
        source = (ROOT / 'scripts/inspect_release_macho.py').read_text()
        bad_signature = bytearray(signed_slice('roothide'))
        bad_signature[600] ^= 1
        cases = [
            ("assert cd[hash_off + n * hash_size:hash_off + (n + 1) * hash_size] == expected, 'Code page hash mismatch'", 'pass', bytes(bad_signature)),
            ("assert (platform, minimum, sdk) == (2, 0xf0000, 0x110500), 'Wrong iOS minimum/SDK'", 'pass', signed_slice('roothide', minimum=0xe0000)),
            ("assert len(result) == len(expected) and {x['arch'] for x in result} == expected, 'Wrong CPU slices'", 'pass', signed_slice('roothide', 'arm64')),
        ]
        for old, replacement, raw in cases:
            with self.subTest(guard=old):
                self.assertEqual(source.count(old), 1)
                with self.assertRaises(AssertionError):
                    checker.inspect(raw, 'roothide')
                namespace = {}
                exec(compile(source.replace(old, replacement), 'mutated_checker', 'exec'), namespace)
                self.assertTrue(namespace['inspect'](raw, 'roothide')['slices'])

    def test_rootless_dependency_is_pinned_framework_not_fabricated_lib(self):
        for wrong in ('@rpath/libsubstrate.dylib', '@loader_path/.jbroot/usr/lib/libsubstrate.dylib'):
            raw = fat([(0x100000c, 0, signed_slice('rootless', 'arm64', dependency=wrong)),
                       (0x100000c, 0x80000002, signed_slice('rootless', dependency=wrong))])
            with self.assertRaises(AssertionError):
                checker.inspect(raw, 'rootless')

    def test_staged_metadata_is_idempotent_and_rejects_stale_scheme(self):
        for scheme in ('rootless', 'roothide'):
            fields, _ = fixture(scheme)
            fields.pop('Tag', None)
            path = self.work / 'control'
            path.write_text(''.join(k + ': ' + v + '\n' for k, v in fields.items()))
            meta.stage(path, scheme)
            first = path.read_bytes()
            meta.stage(path, scheme)
            self.assertEqual(first, path.read_bytes())
        fields, _ = fixture('rootless')
        fields['Tag'] = 'supports::roothide'
        path.write_text(''.join(k + ': ' + v + '\n' for k, v in fields.items()))
        with self.assertRaises(ValueError):
            meta.stage(path, 'rootless')
        with self.assertRaises(ValueError):
            meta.parse_control('Version: 1\nVersion: 2\n')

    def test_make_project_scheme_expansion_and_invalid_inputs(self):
        # Executes the production Makefile; stub includes avoid pretending that
        # Linux has Xcode/Theos. Real pinned Theos/Apple compilation stays in CI.
        theos = self.work / 'theos'
        makefiles = theos / 'makefiles'
        makefiles.mkdir(parents=True)
        (makefiles / 'common.mk').write_text('THEOS_MAKE_PATH := $(THEOS)/makefiles\n')
        (makefiles / 'tweak.mk').write_text("print_config:\n\t@printf '%s\\n' '$(THEOS_PACKAGE_SCHEME)|$(ARCHS)|$(TARGET)|$(ProMotion120_FILES)'\n")
        # The CI matrix exports PM_SCHEME; fixture expectations intentionally
        # cover both schemes and the clean default independently of that job.
        environment = os.environ.copy()
        for name in ('PM_SCHEME', 'THEOS_PACKAGE_SCHEME', 'ARCHS'):
            environment.pop(name, None)
        for arguments, expected in [([], 'roothide|arm64e'), (['PM_SCHEME=roothide'], 'roothide|arm64e'),
                                    (['PM_SCHEME=rootless'], 'rootless|arm64 arm64e'),
                                    (['THEOS_PACKAGE_SCHEME=rootless'], 'rootless|arm64 arm64e'),
                                    (['PM_SCHEME=rootless', 'ARCHS=arm64e'], 'rootless|arm64 arm64e')]:
            result = subprocess.run(['make', '-s', '-f', str(ROOT / 'Makefile'), 'THEOS=' + str(theos),
                                     *arguments, 'print_config'], capture_output=True, text=True, env=environment)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), expected + '|iphone:clang:17.5:15.0|Tweak.xmi')
        for arguments in [['PM_SCHEME=unsupported'], ['PM_SCHEME=roothide', 'THEOS_PACKAGE_SCHEME=rootless']]:
            result = subprocess.run(['make', '-s', '-f', str(ROOT / 'Makefile'), 'THEOS=' + str(theos),
                                     *arguments, 'print_config'], capture_output=True, text=True, env=environment)
            self.assertNotEqual(result.returncode, 0)

    def test_version_upgrade_and_workflow_contract(self):
        fields = meta.parse_control((ROOT / 'control').read_text())
        self.assertEqual(fields['Version'], '1.0.14-1')
        self.assertNotIn('Tag', fields)
        for old in ('1.0.13', '1.0.13-2+ab1', '1.0.13-2+k1', '1.0.13-2+s1', '1.0.13-2+hdr1'):
            subprocess.run(['dpkg', '--compare-versions', fields['Version'], 'gt', old], check=True)
        workflow = (ROOT / '.github/workflows/release-build.yml').read_text()
        for required in ['scheme: [roothide, rootless]', 'fail-fast: false', 'fetch-depth: 0',
                         '88506b2c22e9e07dd4ed055f23c9e398a117a2c7', 'github.com/roothide/theos.git',
                         'fetch --depth 1 origin 88506b2c22e9e07dd4ed055f23c9e398a117a2c7',
                         'python3 tests/test_dual_release.py -v', '--canonicalize', '--scheme "$PM_SCHEME"',
                         'python3 scripts/verify-release-source.py', 'set -euo pipefail',
                         'incompatible arm64e ABI compiler', 'git diff --exit-code']:
            self.assertIn(required, workflow)
        self.assertNotIn('github.com/theos/theos.git', workflow)
        for scheme in ('rootless', 'roothide'):
            self.assertFalse((ROOT / f'.github/workflows/{scheme}-build.yml').exists())

    def test_manifest_bound_to_actual_hdr1_git_blobs(self):
        manifest = json.loads((ROOT / 'tests/release-baseline.json').read_text())
        self.assertEqual(manifest['baseline'], '25e29f3a5b7fbb5ba5ef1c488024e31f6d921751')
        self.assertEqual(len(manifest['files']), 18)
        for name, record in manifest['files'].items():
            blob = subprocess.check_output(['git', '-C', str(ROOT), 'show', manifest['baseline'] + ':' + name])
            self.assertEqual(hashlib.sha256(blob).hexdigest(), record['sha256'])
        self.assertTrue(freeze.check()['bytes_and_modes_unchanged'])

    def test_production_freeze_negative_cases(self):
        repo = self.work / 'repo'
        shutil.copytree(ROOT, repo, ignore=shutil.ignore_patterns('.git', '__pycache__'))
        self.assertTrue(freeze.check(repo)['bytes_and_modes_unchanged'])
        tweak = repo / 'Tweak.xmi'
        original = tweak.read_bytes()
        tweak.write_bytes(original + b'\n')
        with self.assertRaises(ValueError):
            freeze.check(repo)
        tweak.write_bytes(original)
        tweak.chmod(0o755)
        with self.assertRaises(ValueError):
            freeze.check(repo)
        tweak.chmod(0o644)
        extra = repo / 'src/extra.inc'
        extra.write_text('extra')
        with self.assertRaises(ValueError):
            freeze.check(repo)
        extra.unlink()
        filter_path = repo / 'ProMotion120.plist'
        filter_path.unlink()
        filter_path.symlink_to(ROOT / 'ProMotion120.plist')
        with self.assertRaises(ValueError):
            freeze.check(repo)


if __name__ == '__main__':
    unittest.main()
