#!/usr/bin/env python3
"""Execute production timing window and Objective-C wrapper; not device FPS tests."""
from pathlib import Path
import platform
import shlex
import subprocess
import tempfile
import unittest
from test_float_metadata_scope import function

ROOT = Path(__file__).resolve().parents[1]

C_TEST = r'''
#include "PMFrameTiming.h"
#include <assert.h>
#include <stdio.h>
static void steady(double rate) {
    PMFrameTimingWindow w = {0}; double hz = 999; unsigned ready = 0;
    assert(PMFrameTimingPush(&w,100,&hz)==PMFrameTimingWaiting && hz==0);
    for (unsigned i=1; i<=(unsigned)(rate*8); i++) {
        PMFrameTimingResult r=PMFrameTimingPush(&w,100+i/rate,&hz);
        if(r==PMFrameTimingReady) { assert(fabs(hz-rate)<1e-8); ready++; }
        else assert(r==PMFrameTimingWaiting && hz==0);
    }
    assert(ready>=7 && w.resets==0);
}
static void discontinuity(double bad) {
    PMFrameTimingWindow w={0}; double hz=999;
    PMFrameTimingPush(&w,100,&hz); PMFrameTimingPush(&w,100.5,&hz);
    assert(PMFrameTimingPush(&w,bad,&hz)==PMFrameTimingReset && hz==0);
    assert(w.resets==1 && w.intervals==0);
    // Recover from the production reset state, without repairing it in the test.
    double start = isfinite(bad) && bad > 0 ? bad : 200;
    if (!isfinite(bad) || bad <= 0)
        assert(PMFrameTimingPush(&w,start,&hz)==PMFrameTimingWaiting && hz==0);
    for(int i=1;i<=120;i++) {
        int r=PMFrameTimingPush(&w,start+i/120.0,&hz);
        if(i<120) assert(r==PMFrameTimingWaiting && hz==0);
        else assert(r==PMFrameTimingReady && fabs(hz-120)<1e-9);
    }
}
int main(void) {
    double rates[]={1,20,24,60,80,120,144};
    for(unsigned i=0;i<sizeof(rates)/sizeof(*rates);i++) steady(rates[i]);
    double bad[]={100.5,99,103,0,-1,NAN,INFINITY,-INFINITY};
    for(unsigned i=0;i<sizeof(bad)/sizeof(*bad);i++) discontinuity(bad[i]);
    PMFrameTimingWindow w={0}; double hz=42;
    PMFrameTimingPush(&w,100,&hz);
    // Alternating 4/12ms jitter averages to 125 callbacks/s; no frame inference.
    double t=100;
    for(int i=1;i<=250;i++) {
        t+=(i%2?.004:.012);
        if(PMFrameTimingPush(&w,t,&hz)==PMFrameTimingReady)
            assert(hz>124 && hz<126);
    }
    w.resets=UINT_MAX; assert(PMFrameTimingPush(&w,NAN,&hz)==PMFrameTimingReset);
    assert(w.resets==UINT_MAX && hz==0);
    PMFrameTimingLogState s={0};
    assert(!PMFrameTimingShouldLog(&s,NAN,120,0));
    assert(!PMFrameTimingShouldLog(&s,100,NAN,0));
    assert(!s.hasLogged);
    assert(PMFrameTimingShouldLog(&s,100,120,0)); // first good window
    assert(!PMFrameTimingShouldLog(&s,101,60,0));
    assert(!PMFrameTimingShouldLog(&s,99,60,0)); // monotonic guard
    assert(PMFrameTimingShouldLog(&s,105,60,0));
    assert(!PMFrameTimingShouldLog(&s,106,120,0));
    assert(PMFrameTimingShouldLog(&s,110,120,0)); // recovery
    assert(!PMFrameTimingShouldLog(&s,115,120,0)); // healthy silence
    assert(PMFrameTimingShouldLog(&s,115,120,1)); // reset report
    assert(!PMFrameTimingShouldLog(&s,116,60,2)); // reset shares rate limit
    assert(PMFrameTimingShouldLog(&s,120,60,2));
    assert(PMFrameTimingShouldLog(&s,125,60,2)); // recurring anomaly
    puts("PASS 7 steady rates, 8 discontinuities, jitter, saturation, log budget");
}
'''

OBJC_PREFIX = r'''
#import <Foundation/Foundation.h>
#include <assert.h>
#include <stdarg.h>
#include "PMFrameTiming.h"
#define TARGET_FPS 120
static double stamp=100, durationValue=1.0/120, targetValue, monotonic=100;
static int durationReads, targetReads, logs;
static double loggedHz, loggedDuration, loggedDelta;
static BOOL PMQuartzCoreRestrictionSubmitted=YES, PMQuartzCoreArbitrationSubmitted=YES;
#define CACurrentMediaTime() monotonic
@interface CADisplayLink : NSObject
- (double)timestamp;
- (double)duration;
- (double)targetTimestamp;
@end
@implementation CADisplayLink
- (double)timestamp { return stamp; }
- (double)duration { durationReads++; return durationValue; }
- (double)targetTimestamp { targetReads++; return targetValue; }
@end
static void captureLog(NSString *format, ...) {
    assert([format containsString:@"not game FPS or panel Hz"]);
    assert([format containsString:@"scope=sb_keepalive"]);
    va_list a; va_start(a,format); loggedHz=va_arg(a,double);
    assert(va_arg(a,int)==120); loggedDuration=va_arg(a,double); loggedDelta=va_arg(a,double);
    va_end(a); logs++;
}
#define NSLog captureLog
static PMFrameTimingWindow PMQuartzCoreTiming={0};
static PMFrameTimingLogState PMQuartzCoreTimingLog={0};
'''

OBJC_TAIL = r'''
int main(void) { @autoreleasepool {
    CADisplayLink *link=[CADisplayLink new];
    PMQuartzCoreRecordKeepAliveTick(nil); assert(logs==0);
    for(int i=0;i<=120;i++) {
        stamp=100+i/120.0; monotonic=stamp; targetValue=stamp+1.0/120;
        PMQuartzCoreRecordKeepAliveTick(link);
    }
    assert(logs==1 && fabs(loggedHz-120)<1e-9);
    assert(durationReads==1 && targetReads==1 && loggedDuration>0 && loggedDelta>0);
    PMQuartzCoreRecordKeepAliveTick(link); // duplicate: no stale valid sample
    assert(logs==1 && PMQuartzCoreTiming.resets==1);
    durationValue=NAN; targetValue=-INFINITY;
    for(int i=1;i<=5*120;i++) {
        stamp=101+i/120.0; monotonic=stamp;
        PMQuartzCoreRecordKeepAliveTick(link);
    }
    assert(logs==2 && durationReads==2 && targetReads==2);
    assert(loggedDuration==0 && loggedDelta==0);
    unsigned resets=PMQuartzCoreTiming.resets;
    stamp+=10; monotonic=stamp;
    PMQuartzCoreRecordKeepAliveTick(link);
    assert(logs==2 && PMQuartzCoreTiming.resets==resets+1);
    puts("PASS actual callback wrapper, nil, sparse reads, invalid hints, reset");
} return 0; }
'''


def run_host(source_text, objc=False):
    with tempfile.TemporaryDirectory(prefix='pm-timing-') as d:
        directory=Path(d)
        source=directory/('test.m' if objc else 'test.c')
        binary=directory/'test'
        source.write_text(source_text)
        checks=['-I'+str(ROOT/'src'), '-Wall', '-Wextra', '-Werror', '-std=gnu11']
        if objc and platform.system()=='Darwin':
            cmd=['xcrun','--sdk','macosx','clang',*checks,str(source),'-framework','Foundation','-o',str(binary)]
        elif objc:
            flags=shlex.split(subprocess.check_output(['gnustep-config','--objc-flags'],text=True))
            libs=shlex.split(subprocess.check_output(['gnustep-config','--base-libs'],text=True))
            inc=subprocess.check_output(['gcc','-print-file-name=include'],text=True).strip()
            cmd=['clang',*flags,*checks,'-I'+inc,str(source),'-o',str(binary),*libs]
        else:
            cmd=['clang',*checks,str(source),'-o',str(binary),'-lm']
        build=subprocess.run(cmd,cwd=directory,capture_output=True,text=True)
        if build.returncode:
            raise AssertionError(build.stdout+build.stderr)
        result=subprocess.run([str(binary)],cwd=directory,capture_output=True,text=True)
        if result.returncode:
            raise AssertionError(result.stdout+result.stderr)
        return result.stdout


class FrameTimingTests(unittest.TestCase):
    def test_production_window_and_log_budget(self):
        self.assertIn('PASS',run_host(C_TEST))

    def test_actual_objc_callback_wrapper(self):
        quartz=(ROOT/'src/PMQuartzCoreHooks.xm.inc').read_text()
        body=function(quartz,'PMQuartzCoreRecordKeepAliveTick')
        self.assertIn('PASS',run_host(OBJC_PREFIX+body+OBJC_TAIL,objc=True))

    def test_rejects_timing_mutations(self):
        header=(ROOT/'src/PMFrameTiming.h').read_text()
        mutations=[
            ('w->intervals = 0; // First event', 'w->intervals = 1; // First event'),
            ('*callbackHz = 0; // Never', '*callbackHz = 120; // Never'),
            ('timestamp <= w->previous', 'timestamp < w->previous'),
            ('now - s->lastLogTime < 5.0', 'now - s->lastLogTime < 0.0'),
        ]
        for old,new in mutations:
            with self.subTest(mutation=old):
                self.assertEqual(header.count(old),1)
                code=C_TEST.replace('#include "PMFrameTiming.h"',header.replace(old,new))
                with self.assertRaises(AssertionError):
                    run_host(code)

    def test_no_new_control_or_private_getters_in_sampler(self):
        quartz=(ROOT/'src/PMQuartzCoreHooks.xm.inc').read_text()
        body=function(quartz,'PMQuartzCoreRecordKeepAliveTick')
        for forbidden in ['CFAbsoluteTimeGetCurrent','dispatch_','NSClassFromString',
                          'objc_msgSend','setPreferred','actualFramesPerSecond',
                          'CAWindowServer','PMGlobalSBApply','PMForce120Range']:
            self.assertNotIn(forbidden,body)
        self.assertIn('link.timestamp',body)
        self.assertIn('link.duration',body)
        self.assertIn('link.targetTimestamp',body)
        workflow=(ROOT/'.github/workflows/release-build.yml').read_text()
        self.assertIn('scheme: [roothide, rootless]',workflow)
        self.assertIn('python3 tests/test_frame_timing.py -v',workflow)
        self.assertIn('python3 tests/test_header_reason_policy.py -v',workflow)


if __name__=='__main__':
    unittest.main()
