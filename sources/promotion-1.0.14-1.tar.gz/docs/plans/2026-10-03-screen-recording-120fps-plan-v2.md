# ProMotion 录屏 120fps：模型复审后的正式计划 v2

日期：2026-10-03
基线：`feat/quartzcore-stubs` / `cd3b1b9` / P1 Actions `37038867779`
状态：设备 A/B 已确认当前录屏 dylib 会导致系统录屏不可用；当前候选已回滚，进入隔离调试，尚未可发布。

## 0. 多模型裁决与采纳边界

本轮实际返回 3 份独立意见：Grok 4.7、GPT 5.6 Luna、Gemini 3.8 Flash；DeepSeek/Kimi请求超时或 provider 失败。三份返回意见共同支持：

- 不把旧 ProMotion dylib 直接注入 replayd 再依靠 constructor 早退。
- 在同一个 deb 内新增第二个轻量录屏 dylib，单独 filter 只匹配 replayd。
- replayd 中不执行 P1 QuartzCore 双桩、DynamicSource、普通 App bootstrap 或 UIKit Logos 路径。
- 只加 replayd，不扩大到 backboardd/SpringBoard。
- 按完整链路做一个实验候选；核心 Fig/VSync 版只作为内部对照，不发两个同版本包。

没有照抄模型的部分：

- `MSHookMessageEx` 在当前使用的 substrate 头里不能直接当作可返回 bool 的事务 API；计划采用“全量预检 + 固定安装顺序 + 会话闸门 + 失败 inactive + replayd 重启回滚”，不宣称真正原子回滚。
- “TLS 跨线程一定失效”是风险，不是当前样本已证实事实。Hello 自身就用 TLS 做 writer 门控；实现先复刻其链路，再用真机确认 writer 是否在同一上下文。不能未经验证改成关联对象。
- “一定需要 backboardd/SpringBoard”没有证据；继续只匹配 replayd。

## 1. 架构结论

### 1.1 两个 dylib，故障域隔离

保留已有：

```text
ProMotion120.dylib
filter: 现有 UIKit/SpringBoard Bundles
```

新增：

```text
ProMotion120Recording.dylib
filter: Mode=Any + Executables=[replayd]
```

录屏 dylib 不 include 现有 `Tweak.xmi`，不复用 P1 的静态全局、`PMBootstrap`、UIKit Logos hook、DynamicSource hook 或 keepalive。它只拥有自己的 constructor、状态和安装函数。

同一个 deb 可以包含两个 target 和两个 plist，但必须有独立产物名、独立 source contract、独立初始化入口；不能用一个 target 编译两份逻辑后靠运行时早退伪装隔离。

### 1.2 replayd 完全隔离 P1

录屏 dylib 内不调用：

- `PMInstallQuartzCoreHooks`
- `PMInstallDynamicSourceHooks`
- `PMAppEnsurePersistentSource`
- `PMAppRefreshPersistentSource`
- SpringBoard keepalive
- 现有 `%init` / UIKit Logos hook
- `PMDeviceSupports120Hz` 普通 App 路径

现有 ProMotion dylib 的 filter 不增加 replayd。这样旧 dylib 不会被动态加载到 replayd，避免依赖加载、Objective-C 元数据、静态对象和 constructor 副作用。

## 2. 已确认录屏链

### 2.1 核心 Fig 组

- `FigScreenCaptureController` 类方法 `screenCaptureControllerWithSize:minIntervalBetweenFrames:`
- ABI：`CGSize` + 24 字节 `CMTime`，type encoding `{CGSize=dd}` / `{?=qiIq}` 已确认
- 生成 `CMTimeMake(1,120)`
- 设置 `setFigVirtualDisplayOption:@120 forKey:kFigVirtualDisplaySinkOption_VSyncRate`

### 2.2 systemRecording TLS 组

- `RPScreenCaptureManagerIOS startSessionWithPID:...`
- `RPMovieWriter setUpAssetWriterWithHandler:`
- 只对 `systemRecording` 为真写入 Hello 同语义 TLS sentinel
- 不假设 TLS 自动跨队列传播；如果真机证明 writer 位于不同线程，第二个候选必须先保持 writer 补丁 inactive，而不是擅自改门控机制

### 2.3 writer 组

只在 systemRecording 上下文且确认是视频输入时：

```text
copy = [outputSettings mutableCopy]
comp = outputSettings[CompressionProperties]
compEdit = comp ? [comp mutableCopy] : [NSMutableDictionary dictionary]

旧 ExpectedSourceFrameRate < 120 → ExpectedSourceFrameRate = @120
MaxKeyFrameInterval = @120
旧 AverageBitRate > 0 → AverageBitRate = old * 2

copy[CompressionProperties] = compEdit
调用原始 initWithMediaType:outputSettings:
```

四个键值和门控已在 `FINDINGS.md` 第十三节、`asset-notes-writer.md` 中落盘。旧帧率门和码率门的“谓词方向”仍标为数据依赖，源码实现必须先通过等价 CFG/host fixture 验证，不能把“写入意图”冒充静态 branch direction。

必须加视频轨道守卫：二进制导入 `_AVMediaTypeVideo` 且在 writer 流程中有相关门控；源码需要先确认 `mediaType` 与该常量的比较路径。不能改音频输入或非视频 `AVAssetWriterInput`。

## 3. 安装协议

### P0：能力预检，零 hook

在 constructor 中只做：

1. 确认可执行文件是 replayd 允许变体；
2. 确认 OS/build/架构在 allowlist；
3. `NSClassFromString` 获取四个目标类；
4. 获取所有 selector，确认类方法/实例方法类型；
5. 确认 VSync dlsym key；
6. 获取所有原始 IMP/方法签名；
7. 确认 `CMTime`/`CGSize` ABI contract；
8. 确认视频类型常量和 writer 门控能力。

任一项失败：不安装任何 hook，打印一次 `unavailable; inactive`，保留系统原始录屏路径。

### P1：固定安装顺序

只对 distinct selector 安装一次。7 个逆向调用点不是 7 个不同方法，源码不得重复 hook 同一 selector。

安装顺序：

```text
Fig 工厂
→ startSession TLS
→ RPMovieWriter setup TLS
→ AVAssetWriterInput writer
→ 全部原始 IMP 非空检查
→ RecordingActive = true
```

`MSHookMessageEx` 没有可依赖的事务回滚。安装过程中任何失败都把功能状态保持 inactive；已经写入的方法表只能以 replayd 进程重启作为回滚边界。hook 桩第一行必须检查功能闸门，inactive 时直接调用对应原始 IMP，不能继续修改参数。

### P2：会话状态

- systemRecording TLS key 只在录屏 dylib 内创建和使用。
- start/stop/cancel/failure/daemon restart 都要清理本进程状态。
- 不在 VSync 或 writer 热路径写文件、阻塞等待、创建无界队列或刷逐帧日志。
- 日志只记录 hook 版本、能力状态、失败类别和 session 结果，不记录 TLS 指针、录制内容或敏感对象。

## 4. 构建与包结构

需要新增：

```text
Recording.xm 或独立 TweakRecording.xmi
ProMotion120Recording.plist
```

Makefile 采用两个独立 target，录屏 target 按需链接 Foundation/CoreMedia/AVFoundation/Substrate/dlsym 所需库；不链接 UIKit/QuartzCore，除非实际编译接口证明不可避免。

录屏 plist：

```plist
Filter = {
    Mode = Any;
    Executables = (replayd);
};
```

现有 `ProMotion120.plist` 不加 replayd。

## 5. 验证门

### Source contract

必须检查：

- 旧 dylib filter 不含 replayd；新 dylib filter 只含 replayd；
- 录屏源码不 include P1 `Tweak.xmi`/普通 bootstrap；
- 无 UIKit Logos hook、DynamicSource、QuartzCore P1 双桩依赖；
- 同一 selector 只安装一次；
- 预检发生在任何 MSHookMessageEx 前；
- fail-closed 闸门存在；
- writer 只作用于 systemRecording + video；
- 没有逐帧 I/O、无界队列、设置项或用户配置。

### Cloud build

- roothide arm64e 编译；
- 编译日志无 compiler error、无 incompatible arm64e ABI；
- 两个 dylib 的 Mach-O/依赖/架构分别检查；
- 解包后检查两个 plist 的实际 filter；
- 产物单独保存 SHA256，不覆盖 P1 deb。

### 真机 A/B/C

同一系统、同一设备、同一场景比较：

```text
A = 原始基线
B = 核心 Fig/VSync 内部对照
C = 完整 TLS + writer 候选
```

C 之前先验证 B 的录屏启动/停止和实际帧率。验收：

- replayd 实际注入链与目标方法命中日志；
- 冷启动、热启动、重复 start/stop、取消、daemon 被杀重启；
- 60/80/120Hz 内容、旋转、锁屏/后台、HDR/SDR；
- 输出帧数/时长、PTS/DTS 单调性、重复帧率；
- 音视频同步、编码器、分辨率、码率、文件可播放性；
- CPU、内存、温度、功耗、watchdog；
- writer 失败和 hook 预检失败时回到原始路径。

没有这些数据前，不声称“已隔离”“稳定 120fps”“兼容所有设备”或“生产可用”。

## 6. 明确暂不做

- 不把 replayd 加入旧 ProMotion dylib filter；
- 不注入 backboardd/SpringBoard；
- 不保留两个同版本可安装候选包；核心版只作为内部对照；
- 不照抄模型关于 TLS 必然跨线程失效或 MSHookMessageEx 返回 bool 的未经验证断言；
- 不无条件强写 writer 键；
- 不修改全局 Metal pacing；
- 不在真机验收前合并稳定分支或发布。

## 7. 复审补充边界（2026-10-03）

- 三个模型共同支持独立轻量 replayd dylib；Grok/Luna/Gemini 返回，DeepSeek/Kimi失败。
- 反方最强风险：实际录屏可能经 XPC 转发到另一个 helper，需真机抓进程链确认；不能仅凭静态 filter 声称 replayd 是唯一数据路径。
- 录屏 target 只注入 replayd；原 ProMotion dylib 继续保留原 Bundle filter，不能把 replayd 加进旧 filter。
- writer 的 `_AVMediaTypeVideo` GOT 槽为 0x88378，确有引用；源码必须补视频类型条件，不改音频输入。其完整控制流门尚需 host/真机对照，暂不把“已完全确认”写成事实。
- 原逆向链明确在 startSession 原始调用后有第二次 `pthread_setspecific`，因此源码不能只写“start 前打标”而忽略原链的恢复/清理时机；需在实现前按该调用点复刻并测试异常路径。
- `MSHookMessageEx` 无事务；预检和闸门只能做到 fail-closed 逻辑，不能撤销已改的方法表；replayd 重启是回滚边界。

## 8. P1 implementation checkpoint（2026-10-03）

首批生产实现已落在分支 `feat/screen-recording-120fps`：

- `9337e2e`：独立 `ProMotion120Recording` target / `Recording.xmi` / replayd-only filter / source contract；实现了四个 distinct selector 的预检和 hook 框架。
- `2298b6e`：ARC 的 `__bridge` 修正与 rootless runner openssl 清理。
- `24d33ec`：补齐 Theos 要求的根目录 `ProMotion120Recording.plist`。
- roothide Actions `37103011014` 成功；rootless Actions `37103015014` 成功。
- roothide deb SHA256：`e07d185c26a7c316c0b849a229752e07ccfb7c6cc838d07c9094af6534c9a0a1`。
- rootless deb SHA256：`5e09875b4133615ba8717e1639c554f7ce3f3659de78bc54b467d6a517e39645`。
- 包内核对通过：旧 filter 仍只有原 Bundles；新 filter 是 `Mode=Any + Executables=[replayd]`；录屏 dylib 链接 Foundation/CoreFoundation/CoreMedia/AVFoundation/Substrate，无 UIKit/QuartzCore。
- 当前仅完成云端编译、包结构和静态 contract；未真机安装、未确认进程名检测、未确认 dlsym key 对象语义、未确认 Fig CMTime ABI、TLS 是否跨 writer 上下文、实际帧率或稳定性。
