# ProMotion 录屏 120fps：独立接入计划

日期：2026-10-03
状态：仅完成计划与边界冻结，尚未修改生产代码、尚未创建提交
基线：`feat/quartzcore-stubs` / `cd3b1b9` / P1 Actions `37038867779`

## 1. 目标与边界

目标是在系统录屏链路中请求 120fps，优先覆盖 iOS 15.x 的 `replayd` 管线；不把它误称为“任何内容都能生成 120 个独立帧”。如果前台应用只提交 60 个不同帧，录屏端最多可能得到 120Hz 时间基准下的重复帧，必须用实际文件帧数和重复帧分析验收。

本专项与 P1 分开：

- 从 `cd3b1b9` 派生独立功能分支；P1 分支不直接混入录屏代码。
- 不增加设置项、偏好键、排除名单或用户可配置降频项。
- 不复制 Hello 120Hz 的授权、网络、设备绑定、混淆和 RSA 逻辑。
- 不修改现有 Metal present/drawable pacing；1.0.12 已明确这类全局改写可能与录屏 GPU 调度竞争。
- 不在静态证据不足时猜写 `AVAssetWriter` 配置键，不以“能编译”代替真机帧率验收。
- 未通过真机回归前，不发布、不合并到稳定分支。

## 2. 当前证据与未决项

| 项目 | 当前结论 | 置信度/剩余工作 |
|---|---|---|
| 注入进程 | Hello 的 filter 明确包含 `Executables: [SpringBoard, backboardd, replayd]`，录屏专项至少需要 `replayd` | 高；需确认当前 substrate filter 的 `Mode=Any` 表达方式 |
| 入口 | `FigScreenCaptureController` 类方法 `screenCaptureControllerWithSize:minIntervalBetweenFrames:` | 高；需钉死目标类/元类和 ABI |
| VSync 选项 | dlsym `kFigVirtualDisplaySinkOption_VSyncRate`，随后调用 `setFigVirtualDisplayOption:forKey:` | 高；`0xa7db0` 在安装函数 0x4db44/0x4dbb0 两个分支由 dlsym 返回值写入，生命周期已钉死 |
| VSync 值 | 替换函数 0x68f8c 有 `mov w2,#0x78`，随后把 NSNumber 与 VSync key 送入 setter，强烈指向 `@(120)` | 高；需要把调用前后对象/参数 ABI 做最后静态确认 |
| 最小间隔 | 0x6984c 调用 `CMTimeMake(1, 120)`，返回的 24 字节 CMTime 写回入参并复制给原始调用；不是 `double` | 高；源码 hook 必须按 `{?=qiIq}`/CMTime 的 arm64 ABI 保留间接结构参数 |
| Asset writer | 已证实（P0 关闭）：改写 `outputSettings` 的 `CompressionProperties` 子字典——`ExpectedSourceFrameRate=@120`（门：旧值<120）、`MaxKeyFrameInterval=@120`、`AverageBitRate=@(旧值×2)`（门：旧值>0）；四键经 GOT 单载单用全部实锤 | 已可直接编码 |
| session 入口 | `startSessionWithPID:...` 的替换函数 0x6c510：透传 + `pthread_setspecific(0xa7dc0, systemRecording ? &0xa7de8 : NULL)` 打标 | 高；第一版不加无行为 hook |
| writer setup | `setUpAssetWriterWithHandler:` 的替换函数 0x6cfc4：已确认目标类 = `RPMovieWriter`；读 `[self systemRecording]` 复核 TLS 标记 | 已确认 |
| session 入口 | `startSessionWithPID:windowSize:systemRecording:contextIDs:outputHandler:didStartHandler:` 的替换函数 0x6c510 目前看是透传 | 高；第一版不加无行为 hook |
| writer setup | `setUpAssetWriterWithHandler:` 的替换函数 0x6cfc4 读取 `[self systemRecording]` 并写线程局部状态 | 中高；需要先确认目标类是否为 `RPMovieWriter` |

逆向主报告：`/var/minis/workspace/hello120hz-re/FINDINGS.md` 第十一节。

## 3. 关键架构决定

### 3.1 录屏进程必须走独立早期分支

当前 `PMBootstrap` 先调用 `PMDeviceSupports120Hz()`，再按 SpringBoard/非 SpringBoard 分流。`replayd` 不是现有 UIKit app 路径，不能直接把它当普通 app：否则可能执行 `PMAppEnsurePersistentSource()`、应用通知注册和 CADisplay 模式探测，造成无关副作用，甚至在录屏服务进程中提前返回。

计划在 `PMBootstrap` 的最前面增加：

1. `PMIsScreenRecordingProcess()`，基于可验证的进程名/可执行文件名识别 `replayd`。
2. 若为 `replayd`，只调用 `PMInstallScreenRecordingHooks()`，完成后结束该进程的 ProMotion bootstrap。
3. 普通 SpringBoard/App 流程的 `PMDeviceSupports120Hz()`、DynamicSource、keepalive 和现有 hook 顺序保持不变。

### 3.2 新建独立 include-only 模块

新增 `src/PMScreenRecordingHooks.xm.inc`，由 `Tweak.xmi` 引入；不把录屏逻辑塞入 `PMQuartzCoreHooks.xm.inc` 或现有渲染 hook。

模块职责：

- 进程识别和一次性安装状态。
- 动态查找类/selector，类或 selector 缺失时安全 inactive。
- `FigScreenCaptureController` 的最小录屏链路 hook。
- dlsym VSync key 和 selector 的能力检查。
- 限频日志与 session 级状态，不做逐帧 I/O。

`PMInternalDeclarations.xm.inc` 只增加最小安装函数声明。除 `replayd` 早期分支和新模块外，不改现有生产 hook 逻辑。

### 3.3 第一版只做最小闭环

第一版候选范围：

1. 在 `replayd` 中安装 `FigScreenCaptureController` 的类方法 hook。
2. 保留原始 size 和其他参数，按已证实的 ABI 将最小捕获间隔请求为 120fps。
3. 在控制器对象上设置 `kFigVirtualDisplaySinkOption_VSyncRate` 为 `@(120)`。
4. 调用原始实现并保留返回值/异常行为。
5. 输出一次安装状态和每次录屏 session 最多一次的结果日志。

第一版**不强行改** `AVAssetWriterInput` 的 `outputSettings`。只有在静态反汇编确认具体键、类型、调用时机，并且最小闭环在设备上能生成可验证的 120fps 文件后，才考虑第二版 writer 设置补丁。

`startSession...` 的透传替换和 `setUpAssetWriterWithHandler:` 的线程局部状态也不作为第一版必需代码；如果第一版需要识别 system recording，再单独引入已证实的 `systemRecording` 判定，不写无行为的装饰 hook。

## 4. 分阶段执行

### P0：静态证据锁定

- 解出安装函数中所有录屏类名、元类/实例方法归属。
- 钉死 0x68f8c 的真实 Objective-C ABI：size、CMTime interval、返回值和原始调用参数。
- 追完 `0xa7db0` VSync key 的写入者和生命周期（已确认 0x4db44/0x4dbb0 两个安装分支写入 dlsym 结果）。
- 查明 0x6a080 是否真的改写 outputSettings；若未证实，将其排除第一版。
- 记录每个 selector 缺失时的预期 inactive 路径。

当前 P0 已全部关闭（2026-10-03 深夜）：

- 录屏间隔：24 字节 CMTime，`CMTimeMake(1,120)` 实锤；调用约定 `(CGSize, CMTime)`（type encoding `{CGSize=dd}` + `{?=qiIq}`）。
- 站点类身份：FigScreenCaptureController（sites 1/2）、AVAssetWriterInput（site 3，classref 0x8c418 实名）、RPScreenCaptureManagerIOS（sites 4/5）、RPMovieWriter（site 6）——全部锁定（溢出块单写者链 + 语义吻合）。
- Writer 键值：四键（ESFR=120、MaxKeyInterval=120、码率×2）与两个门、字典改写路径全部实锤（见 FINDINGS.md 第十三节 A）。
- 日志点：`1/120`（0x4c380/0x4c418）、`unavailable`（0x4d9b4）与门控校验块（strcmp "{CGSize=dd}"）已定位。

剩余小尾巴（不阻塞、已记录）：三组双装动机、x22→0xa7db0 的微来源、两个门的数据依赖分支方向。


独立失败信号：任何 hook 的类名、selector、参数 ABI 仍只能靠猜测时，不进入源码实现。

### P1：源代码骨架与过滤器

- 从 `cd3b1b9` 派生独立分支。
- 新增录屏模块和最小内部声明。
- 在注入 plist 中用已验证的 substrate 结构加入 `Executables: replayd`，保留现有 Bundles 目标；必要时显式设置 `Mode: Any`，并用包内解析脚本验证。
- 加入 `PMIsScreenRecordingProcess()` 早期分支。

独立失败信号：replayd 进入现有普通 app 分支；普通 SpringBoard/App 的 hook 顺序、包过滤或现有行为发生变化。

### P2：最小 Fig/VSync hook

- 仅实现 P0 已钉死的 hook。
- 保存原始 IMP，安装过程幂等。
- 所有能力缺失只记录 `unavailable; inactive`，不崩溃、不阻塞录屏。
- 不在帧回调里分配集合、写文件或 dispatch。

独立失败信号：原始参数/返回对象变化、普通录屏无法启动、hook 重入/重复安装、出现逐帧日志或文件写入。

### P3：可选 AssetWriter 补丁

仅在 P0 静态证据和 P2 真机结果都支持时执行。只加入已证实的帧率键和类型；否则保持 P2，不为“看起来像 120”添加猜测配置。

### P4：构建与静态验收

- 新增 source contract：进程早期分支、模块 include、过滤器 `replayd`、幂等安装、无设置项、无逐帧 I/O。
- `git diff --check`。
- roothide/rootless 可用 workflow 均编译；检查日志中无 compiler error 和 incompatible arm64e ABI。
- 解包检查 `control`、DynamicLibraries plist、架构 Mach-O、依赖和符号/selector 字符串。
- 把 P1 已有 QuartzCore 构建与录屏专项构建分开保存，方便回滚。

### P5：真机验收

对同一设备、同一系统、同一录屏场景做基线/候选 A/B：

1. 普通启动、切后台、停止/重新开始录屏，无 SpringBoard/replayd 崩溃。
2. 静态画面和 60fps 内容各录一段，确认无启动失败、异常黑屏、音画错位。
3. 让前台产生真实 120Hz 动态内容，录制固定时长；用输出文件的 track `avg_frame_rate`、实际帧数/时长和重复帧比例判断是否达到真实 120fps，而不是只看系统显示刷新率。
4. 检查录屏分辨率、编码器、码率、音频、文件可播放性与基线差异。
5. 检查日志：只出现安装/session 级日志，无逐帧刷屏；类或符号不存在时明确 inactive。
6. 观察发热、功耗、文件体积和长录制稳定性；120fps 不能以录屏服务被杀或明显异常为代价。

建议验收门槛：输出文件可稳定解码，测得帧率接近 120fps（而非仅 nominal metadata=120），无录屏启动/停止回归；若前台源只有 60 个独立帧，应把“重复帧”单独报告，不能把时间基准误判为内容帧率。

## 5. 明确不做的事情

- 不直接复制 Hello 的混淆字符串或付费授权体系。
- 不把 `replayd` 当普通 app 执行 DynamicSource/keepalive。
- 不改全局 Metal present 时序。
- 不修改现有 CADisplayLink/CAAnimation 的 120Hz实现来“顺带”做录屏。
- 不猜 `AVVideoExpectedSourceFrameRateKey`、码率或关键帧参数；这些要等静态证据和设备结果。
- 不在 P1 稳定分支上直接提交，不发布未经过真机帧数验收的 deb。

## 6. 回滚与交付边界

回滚只需撤掉录屏模块 include、`replayd` 过滤器和 bootstrap 早期分支；P1 QuartzCore 双桩及 keepalive 不变。首个录屏候选包单独归档并保留 SHA256，不覆盖已验证的 P1 产物。

计划通过后，下一步不是直接写所有 hook，而是先完成 P0 的四个静态未决项，再给出一份“已证实 ABI + 具体源码改动清单”。
