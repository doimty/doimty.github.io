# Phase P1 implementation review notes

- Branch: `feat/screen-recording-120fps`
- Commits: `9337e2e` skeleton, `2298b6e` ARC/runner fix, `24d33ec` target filter plist.
- Cloud builds: roothide `37103011014` success; rootless `37103015014` success.
- Artifacts: roothide SHA256 `e07d185c26a7c316c0b849a229752e07ccfb7c6cc838d07c9094af6534c9a0a1`; rootless SHA256 `5e09875b4133615ba8717e1639c554f7ce3f3659de78bc54b467d6a517e39645`.
- Package inspection: both contain old ProMotion120 plus ProMotion120Recording; old filter remains Bundles only; recording filter is Mode=Any + Executables=replayd.
- Recording dylib linked libraries: Foundation, CoreFoundation, CoreMedia, AVFoundation, ObjC, substrate, System; no UIKit/QuartzCore.
- Recording dylib includes four runtime replacements and full preflight/active gate; no device install or frame-rate acceptance yet.

Known implementation risks to resolve before calling this device-ready:
1. Fig replacement ABI is still represented as `CMTime *` based on disassembly; must validate with an arm64 host/target contract or device smoke, including returned object/pass-through.
2. `kFigVirtualDisplaySinkOption_VSyncRate` dlsym value is passed as the Objective-C key per Hello; target must validate object/key semantics on device before keeping active.
3. `startSession` TLS is restored immediately after the original call in our first implementation; Hello's original chain sets sentinel before the call and clears/restores after. Writer setup similarly restores after its call. Need device/log validation that writer init occurs inside the same TLS scope; if not, disable writer edit rather than widen scope.
4. `MSHookMessageEx` has no transactional rollback; current code stops and leaves any earlier method hooks installed but `PMRecordingActive` false, so previous hooks pass through. replayd restart is rollback.
5. Constructor's `NSProcessInfo.arguments.firstObject` fallback is a runtime assumption; process filter is the primary guard and device logging must confirm detection.
6. Gate direction for old ExpectedSourceFrameRate and AverageBitRate is implemented from reverse-engineering intent, but static CFG branch direction remains data-dependent; add host dictionary contract before device.

Not yet modified: stable branch, old ProMotion target logic, device configuration, no commit beyond branch code above.
