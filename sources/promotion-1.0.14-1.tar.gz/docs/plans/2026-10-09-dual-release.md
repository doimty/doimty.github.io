# ProMotion 1.0.14-1 dual-environment release preparation

## Scope / authority

- Prepare locally from hdr1 commit `25e29f3a5b7fbb5ba5ef1c488024e31f6d921751`, which received positive user fluidity feedback. Not K1/S1.
- Current request authorizes preparation, not commit, push, CI dispatch, APT publication, installation or device restart.
- Worktree: `promotion-release-1014`, branch `release/1.0.14`. Keep existing hdr1 and experimental trees untouched.
- Freeze `Tweak.xmi`, all `src/**`, both copies of `ProMotion120.plist` byte-for-byte and mode-for-mode. No recording targets, rendering-policy changes or new diagnostic timers.

## Assumptions / changes

- One pinned RootHide Theos revision supports both native package schemes; this is not rootless-compat conversion. Preserve the hdr1 Apple build toolchain (Xcode 15.4, SDK 17.5, deployment 15.0) pending real CI verification.
- RootHide: `arm64e`, `iphoneos-arm64e`, unprefixed jailbreak payload. Rootless: `arm64 arm64e`, `iphoneos-arm64`, `/var/jb` payload. Scheme selects architecture, metadata and paths, not refresh policy.
- Consolidate package jobs into a matrix workflow with independent results (`fail-fast: false`). Remove duplicate automatic package workflows to avoid inconsistent release gates.
- Formal version `1.0.14-1` contains only numbers/punctuation and upgrades all current `1.0.13`/`1.0.13-2+*` releases. Do not merely strip `+hdr1`.
- Add exact production freeze, per-scheme control/paths/architecture checks, numeric-root archive ownership, minimum OS, dependencies and signature checks. Canonicalization must preserve payload/control bytes, types and modes.

## Success criteria / validation

1. All existing host behavioral and retired-module tests pass; CI wiring assertions move to the matrix without deleting behavioral assertions.
2. Both make scheme expansions are checked using real pinned Theos rules. Unsupported schemes fail; rootless cannot retain arm64e-only architecture or RootHide tag.
3. Production freeze detects source/filter/permission/additional-module changes independently.
4. Real archive fixtures exercise package verification, including wrong scheme/tag/architecture, misplaced files, symlinks, owner/setuid and missing binaries. Negative cases must be rejected, not skipped.
5. Future cloud jobs build the real production tweak, examine every Mach-O slice, signed code pages and package dependencies, and upload per-scheme receipts. Apple compilation and real device behavior are separate stages.

## Independent failure signals / boundary

- Any runtime source/filter delta, recording payload, unreviewed compiler-warning suppression, duplicate workflows, missing second slice, wrong package prefix, RootHide metadata in rootless, unsigned/corrupt binary or canonicalization changing payload invalidates preparation.
- Linux/GNUstep tests and make expansion do not prove Apple compilation, PAC behavior, actual panel Hz, game FPS or device fluidity. Rootless has no new device acceptance evidence.
- No new formal deb exists until an authorized cloud build passes. APT source changes and old-package removal are a separate release action.

## Local outcome (2026-10-09)

- Implemented the matrix, scheme architectures, numeric formal metadata, source freeze and archive/signature gates. Production 18-file baseline and original hdr1 worktree remain unchanged.
- 41 tests passed across six independently recorded host suites (old 31 + new 10); static keepalive 15 / render 6 checks, no-recording, actionlint 1.7.4 and diff checks passed. `tests/test_frame_timing.py` changes only its CI-wiring assertion; keepalive static test changes only its exact version assertion.
- Real pinned Theos fragments were retrieved and expanded with native Linux make; this is not full Theos or Apple compilation. Exact rootless `libsubstrate.tbd` is a symlink to `CydiaSubstrate.framework/CydiaSubstrate.tbd`, with install name `@rpath/CydiaSubstrate.framework/CydiaSubstrate`. The verifier and positive/negative fixtures use this observed name and both rootless runtime search paths, not a fabricated dylib path.
- The actual prior hdr1 Apple dylib passed the new code-page signature inspector and the entire root-owned repack pipeline when wrapped in a temporary host archive. That temporary archive was deleted; this is an independent parser positive control, not a newly compiled formal package.
- One final all-in-one rerun was interrupted with shell exit 15 before completion, not counted as pass. Repeated each of the six suites with independent exit/count/OK receipts; all completed (41 total).
- Build/package specialist returned a usable read-only assessment. The separate code-review agent finished with tool-call text instead of findings and supplies no valid independent pass; final diff/toolchain/behavior validation was performed by the main agent. Do not label all independent reviews passed.
- Remaining: authorized commit/push, actual Apple dual job and real new-deb validation, then rootless device acceptance. No commit, push, remote run, publication, installation or restart performed.
- Evidence and patch reconstruction: `/var/minis/workspace/promotion-release-validation/`.
