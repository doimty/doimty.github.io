# 录屏接入模型交叉审查记录

日期：2026-10-03

## 调用结果

- GPT 5.6 Luna：返回完整审查意见，确认独立轻量录屏 dylib 方案。
- Grok 4.7：多次请求超时，未形成第二份意见。因此以下不是“两模型一致”，而是 Luna 的独立意见 + 主线程静态复核。

## 裁决

| 决策 | 结论 |
|---|---|
| Q1 replayd 是否跑 P1 | 不跑。replayd 完全隔离 P1 QuartzCore 双桩、DynamicSource、普通 App bootstrap、keepalive 和 UIKit Logos 初始化。 |
| Q2 交付形态 | 一个完整链候选作为实验交付；核心 Fig/VSync 版只做内部对照，不发布两个同版本 deb。 |
| Q3 安装原子性 | 预检全部能力、固定顺序、幂等、禁用闸门最后打开；明确 `MSHookMessageEx` 无事务和不能可靠回滚，不能宣称真正原子。失败时保持 pass-through/inactive，进程重启是回滚边界。 |
| Q4 注入进程 | 只增加 `replayd`，不扩大到 backboardd/SpringBoard。 |
| Q5 writer | 严格复刻已验证键值和运行时门；门的 CFG 方向仍未完全静态判定，不得把推断方向写死。 |

## 计划必须补充

1. 同一个 deb 可包含第二个独立 target，但旧 `ProMotion120` dylib 的 filter 保持不变；录屏 target 单独 plist，只匹配 `Executables=replayd`。
2. 录屏 target 不直接链接 UIKit/QuartzCore，不复用 P1 的静态全局和 bootstrap；按需使用 Foundation/CoreMedia/AVFoundation/Substrate/dlsym。
3. 录屏 constructor 只做 replayd 身份、OS/build/架构/符号/selector/ABI 全量预检；预检失败不安装任何 hook。
4. 安装阶段先保持 `RecordingActive=0`，安装每个 distinct selector 一次并检查原始函数指针；全部成功后才打开闸门。这里是 fail-closed，不是真事务。
5. TLS 只按 Hello 的 systemRecording 链路使用；不得假设跨线程自动传播。若 writer 不在同一录屏上下文，保持 writer 补丁 inactive，不扩大到全局 writer。
6. Writer 还要确认只改视频输入，不改音频或非视频 `AVAssetWriterInput`；确认失败时禁用 writer 补丁而不是猜。
7. 录屏会话结束、失败、取消和 replayd 重启时清零会话状态；日志不写录制内容、TLS 指针或敏感对象。
8. 增加安装失败、重复加载、部分 hook、重入、daemon 重启、start/stop 并发、磁盘满、长录制、60/120Hz、帧重复率和基线差分测试。

## 最强反例

若把 `replayd` 直接加进旧 dylib 的 filter，再靠 PMBootstrap 中的早退保护，虽然可避免大部分逻辑执行，但旧 dylib 仍会被动态加载并参与依赖加载、Objective-C 元数据注册和 constructor 生命周期；同时很容易在 `%init` 或 early-return 顺序上漏出 P1 hook。它不能作为默认隔离方案，只能作为失败兜底或临时诊断变体。
