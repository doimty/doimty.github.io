# Header-guided refresh candidate (hdr1)

## Scope and baseline

- User authorizes local plugin optimization based on the mounted headers; no commit, push, CI, installation or process restart is authorized.
- Isolated tree `/tmp/promotion-header-guided`, branch `feat/header-guided-refresh`, base `958e70b57620d29025bb1fb478544a028d7ccc5e` (A+B). Not based on K1 or S1.
- Header source: `/var/minis/mounts/Alook/Others/`, ipsw-generated iOS15/SDK15 runtime declarations, not an exact iOS15.1.1 ABI guarantee.
- Old notification-frozen FPS readings are excluded. No claimed game FPS gain.

## Hypotheses / changes

1. DynamicSource accepts a reason array, not a single universal policy code. The current replacement destroys nonempty system arrays in eligible processes. Restrict reason enforcement to plugin-owned sources; foreign source arrays/counts pass unchanged, including clear/release. Remove proactive reason writes from the foreign DynamicSource range replacement, while preserving its existing banner/float range eligibility. Managed sources keep `{1}` on every reason update. This is an ownership-policy candidate, not proof that reason 1 means any particular scheduling policy.
2. Direct reason helper currently calls both single and array setters when present. Prefer the array setter, use single only if absent; no exception-based second write. Existing banner helper has another dual-write path and should use the same direct helper, preserving its existing nil/eligibility guards. Do not touch DisplayLink or CAAnimation request ranges.
3. Existing SB callback sampling counts the first event as an interval and uses civil time. Replace with a small pure-C window driven by public `CADisplayLink.timestamp`. Reject duplicate/regressing/nonfinite timestamps and split long gaps; do not fabricate a frozen rate. Report `keepalive_callback_hz` with public duration/target delta separately, only on initial valid sample, anomalies (5s throttled), and recovery. No new timer, DisplayLink, observer, setter, server object, or private getter. No game FPS inference. No VBL unit guessing: WindowServer integer fields are deliberately not sampled.

## Success criteria

- Actual production replacement executes once; foreign pointer/count/content survive unchanged under app/SB/banner/float combinations; managed requests remain `{1}` and exact 120 range.
- Direct and banner helper choose at most one reason setter per invocation. Neither API present and exceptions are contained without fallback double-write.
- Timestamp model covers 20/24/60/80/120 Hz, jitter, duplicates, resets, long idle gaps and invalid values. No first-event overcount or civil-clock dependency in callback sampler.
- Baseline owner/recovery, metadata, keepalive, render-pacing and no-recording tests still pass. New behavioral tests execute extracted production bodies, not Python copies.
- Diff preserves injection filter, Metal absence, keepalive creation, bootstrap, capability probing and C-hook installation.

## Independent failure signals / rollback

- Any foreign reasons mutation; extra original call; managed request not restored; hot-path allocation/dispatch; sampler reporting a rate across a reset; tests passing only via copied model; changes outside stated control paths.
- On device, worse notification/float behavior or unchanged game fluidity falsifies the benefit hypothesis. Stalls/crashes/thermal regression reject candidate even if logs show 120 callbacks.
- A+B remains untouched and is the source rollback baseline. Compare A+B to hdr1, not K1/S1 to hdr1. Use valid scene/presentation evidence, not the frozen overlay. Diagnostic changes do not prove actual rendered frames.

## Verification boundaries

Host clang/GNUstep and pure C checks validate local logic only. No Apple SDK/Xcode build or arm64e PAC/runtime validation unless explicitly performed later. Header imports will not be copied wholesale because dependencies are absent and generated struct declarations are not compile-safe SDK replacements.
