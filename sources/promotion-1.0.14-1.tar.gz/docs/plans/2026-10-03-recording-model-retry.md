# 录屏架构模型复跑记录

日期：2026-10-03

## 复跑对象

### DeepSeek V4.1 Flash

本轮调用失败：模型实例 `Happy/deepseek-v4.1-flash` 在调用时已不在可用模型列表中。当前配置没有 DeepSeek，无法继续重跑；不是任务内容导致的结论。

### Kimi K3

已用当前实例 `TokenHub/kimi-k3` 重跑两次：

1. 完整短裁决：请求成功，但输出为空，`stop_reason=length`，未形成可用意见。
2. 五行压缩裁决：仍输出为空，`stop_reason=length`，未形成可用意见。

因此 Kimi 本轮也没有有效裁决，不能把它算作支持或反对任何架构方案。

## 当前有效裁决样本

仍只有本轮此前成功返回的：

- Grok 4.7
- GPT 5.6 Luna
- Gemini 3.8 Flash

三者共同支持：旧 ProMotion dylib 不进入 replayd；同 deb 新增只匹配 replayd 的独立轻量 dylib；replayd 隔离 P1；只注入 replayd；完整链作为一个实验候选；预检、固定顺序、fail-closed，不宣称 MSHookMessageEx 可原子回滚。

状态：未修改生产代码，未提交，未推送。
