# ProMotion 录屏接入：P1 兼容性拷问记录

日期：2026-10-03
基线：`feat/quartzcore-stubs` / `cd3b1b9` / P1 Actions `37038867779`
状态：只记录审查结论，尚未修改录屏生产代码；等待架构决策后更新正式计划。

## 已查证事实

### 昨天 P1 当前行为

1. `PMBootstrap` 在 `PMDeviceSupports120Hz()` 成功后先 `%init`，再调用 `PMInstallQuartzCoreHooks()`，再调用 `PMInstallDynamicSourceHooks()`。
2. `PMInstallDynamicSourceHooks()` 设计为所有注入进程安装 `CADynamicFrameRateSource` 两个方法 hook。
3. 非 SpringBoard 分支会注册 `UIApplicationDidBecomeActiveNotification`，并调用 `PMAppEnsurePersistentSource()`。
4. `PMQuartzCoreHooks` 的安装状态是本进程静态状态；它当前没有 replayd 特殊分支。
5. `PMKeepAlive` 只有 SpringBoard 会安装，但其 tick 已调用 `PMQuartzCoreRecordKeepAliveTick()`。
6. 当前 `ProMotion120.plist` 只有 Bundles，没有 `replayd`，因此昨天的 P1 包本身尚未进入 replayd。

### 一旦加入 replayd 后的确定冲突

若只把 `Executables: [replayd]` 加到 filter，而不改 bootstrap，replayd 会：

- 先执行 `%init`，可能安装现有 Logos hook；
- 安装 P1 QuartzCore C-level query stubs；
- 安装 CADynamicFrameRateSource hooks；
- 进入当前普通 App 分支，执行 `PMAppEnsurePersistentSource()` 和 App 前后台通知注册；
- 在一个并非普通 UIKit App 的服务进程里走错初始化路径。

这不是理论冲突，而是当前控制流的直接结果。

### 已知没有直接 selector 碰撞的部分

现有 ProMotion hook 与录屏目标 selector 没有同名重叠：

- 现有：CADisplayLink、CAAnimation、CADynamicFrameRateSource、SpringBoard banner/controller 等；
- 新增目标：FigScreenCaptureController 类方法、RPScreenCaptureManagerIOS startSession、RPMovieWriter setUpAssetWriter、AVAssetWriterInput init。

但同一个进程内仍可能发生间接冲突：`%init`、QuartzCore C stub、DynamicSource hook、普通 App 初始化会一起影响 replayd。

## 结论

- 昨天 P1 与当前普通 SpringBoard/App 路径没有发现必须撤掉的直接冲突。
- 录屏接入与 P1 的真正冲突点是 **replayd 进入普通 bootstrap**。
- 录屏计划必须新增“P1 兼容隔离门”作为源码实现前置条件，位置早于 `%init`、`PMDeviceSupports120Hz()`、`PMInstallQuartzCoreHooks()` 和 `PMInstallDynamicSourceHooks()`。

## 正式计划必须新增的内容

1. 进程矩阵：SpringBoard/App 保持 P1 全路径；replayd 只走录屏路径。
2. replayd 早退位置：`@autoreleasepool` 内最前面，早于 `%init` 和设备探测。
3. replayd 默认不执行：P1 QuartzCore stubs、DynamicSource hooks、keepalive、普通 App persistent source、UIKit Logos 初始化。
4. 过滤器验证：`Mode=Any` + 保留原 Bundles + 增加 `Executables=replayd`；解包后脚本检查实际 plist。
5. 完整录屏依赖链：Fig 双动作 + systemRecording TLS 两处标记/复核 + writer 字典补丁，不再把 writer 键值当未决项。
6. writer 必须复刻原门：旧 ExpectedSourceFrameRate < 120 才写 120；MaxKeyFrameInterval 写 120；旧码率 > 0 才翻倍；只作用于 systemRecording TLS。
7. 独立失败信号：replayd 触发任一普通 App 初始化、普通 App/SpringBoard 的 hook 数量或顺序变化、非 systemRecording writer 被改写、录屏启动/停止失败。
8. 构建验证增加 process-isolation source contract，并保留 P1 基线包用于 A/B。

## 待用户决定的前沿

- replayd 是否完全隔离 P1 双桩（推荐：第一版完全隔离；若设备日志证明录屏仍被 QuartzCore gate 卡住，再做单独变体）。
- 第一候选是否一次实现完整链（推荐：完整实现；静态证据已足，TLS 门控能限制影响面）。
- 首版 filter 是否只加 replayd（推荐：只加 replayd；不要未经证据把 backboardd/SpringBoard 也纳入录屏 hook）。
- writer 是否严格复刻逆向门控（推荐：严格复刻，不做无条件强写）。
