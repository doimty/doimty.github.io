#ifndef PM_FRAME_TIMING_H
#define PM_FRAME_TIMING_H

#include <math.h>
#include <stdbool.h>
#include <limits.h>

// Public CADisplayLink timestamps, in seconds. This is callback cadence,
// NOT unique rendered frames, panel VBL frequency or a game FPS counter.
typedef struct {
    double started, previous;
    unsigned intervals, resets;
} PMFrameTimingWindow;

typedef enum {
    PMFrameTimingReset = -1,
    PMFrameTimingWaiting = 0,
    PMFrameTimingReady = 1
} PMFrameTimingResult;

static inline PMFrameTimingResult PMFrameTimingPush(PMFrameTimingWindow *w,
                                                    double timestamp,
                                                    double *callbackHz) {
    *callbackHz = 0; // Never leave the last successful value in a stale result.
    bool valid = isfinite(timestamp) && timestamp > 0;
    if (!valid || (w->previous > 0 &&
        (timestamp <= w->previous || timestamp - w->previous > 2.0))) {
        if (w->resets < UINT_MAX) w->resets++;
        w->started = w->previous = valid ? timestamp : 0;
        w->intervals = 0;
        return PMFrameTimingReset;
    }
    if (w->previous == 0) {
        w->started = w->previous = timestamp;
        w->intervals = 0; // First event is an anchor, not an elapsed interval.
        return PMFrameTimingWaiting;
    }
    w->previous = timestamp;
    w->intervals++;
    double elapsed = timestamp - w->started;
    if (elapsed < 1.0) return PMFrameTimingWaiting;
    *callbackHz = w->intervals / elapsed;
    w->started = timestamp;
    w->intervals = 0;
    return PMFrameTimingReady;
}

typedef struct {
    double lastLogTime;
    unsigned lastResets;
    bool hasLogged, lastAbnormal;
} PMFrameTimingLogState;

// Call only for a completed valid window. now is CACurrentMediaTime(),
// independent of a link restarting its timestamp sequence. Every log,
// including transitions and reset reports, shares the same 5s rate limit.
static inline bool PMFrameTimingShouldLog(PMFrameTimingLogState *s, double now,
                                         double hz, unsigned resets) {
    if (!isfinite(now) || now <= 0 || !isfinite(hz) || hz <= 0) return false;
    bool abnormal = hz < 100.0 || hz > 130.0;
    if (s->hasLogged && now - s->lastLogTime < 5.0) return false;
    if (s->hasLogged && !abnormal && !s->lastAbnormal && resets == s->lastResets)
        return false;
    s->hasLogged = true;
    s->lastLogTime = now;
    s->lastAbnormal = abnormal;
    s->lastResets = resets;
    return true;
}

#endif
