#ifndef PM_RELIABILITY_H
#define PM_RELIABILITY_H

#include <stdbool.h>
#include <math.h>

// Hardware evidence is independent of hook installation/submission state.
typedef enum {
    PMCapabilityUnknown = 0,
    PMCapabilitySupported,
    PMCapabilityUnsupported
} PMCapability;

typedef struct {
    unsigned seen;
    unsigned valid;
    bool has120;
} PMModeEvidence;

static inline void PMModeEvidenceAdd(PMModeEvidence *e, bool readable, double hz) {
    e->seen++;
    if (!readable || !isfinite(hz) || hz <= 0) return;
    e->valid++;
    if (hz >= 119.0) e->has120 = true;
}

static inline PMCapability PMModeEvidenceResolve(PMModeEvidence e, double hardwareMaximum) {
    if (e.has120) return PMCapabilitySupported;
    // Modes can be an early/partial snapshot. Non-120 modes alone are not proof.
    // The caller supplies only the public maximum read BEFORE our getter hook.
    if (e.valid > 0 && e.valid == e.seen && isfinite(hardwareMaximum)
        && hardwareMaximum > 0 && hardwareMaximum < 119.0)
        return PMCapabilityUnsupported;
    return PMCapabilityUnknown;
}

#define PM_RECOVERY_MAX_ATTEMPTS 9U

typedef struct {
    unsigned attempts;
    bool pending;
    bool running;
} PMRecoveryBudget;

// Main-thread only. Events coalesce with an outstanding timer and cannot extend
// its budget. Once idle/exhausted, a later lifecycle event opens a new window.
static inline bool PMRecoveryBegin(PMRecoveryBudget *s, bool event) {
    if (s->pending || s->running) return false;
    if (event) s->attempts = 0;
    if (s->attempts >= PM_RECOVERY_MAX_ATTEMPTS) return false;
    s->attempts++;
    s->running = true;
    return true;
}

static inline bool PMRecoveryEnd(PMRecoveryBudget *s, bool needsRetry) {
    s->running = false;
    if (!needsRetry || s->pending || s->attempts >= PM_RECOVERY_MAX_ATTEMPTS) return false;
    s->pending = true;
    return true;
}

#endif
