# ProMotion120 refactor progress

## 2026-10-05: A+B daily-refresh reliability candidate

- Based on e53d03b, candidate version 1.0.13-2+ab1; no release/device validation implied.
- Recording experiment retired from current source/build/filter/CI. Ordinary system recording remains the device regression target. Earlier recording notes below and in docs are historical, not current build instructions.
- Startup now has independent lifecycle recovery, conservative capability evidence and bounded/idempotent installation. DynamicSource protection precedes owner creation; QuartzCore status means submission, not proven effect.
- Menu/range/external-screen/Metal policy and keepalive policy are intentionally unchanged. See tests/test_daily_reliability.py and tests/test_no_recording_release.py for executable host gates; an Apple SDK build and device acceptance are still required.

## Baseline

- Branch: `main`
- Commit: `5975beec2e82d174832720647aed52399600c98b`
- Validated behavior baseline: 1.0.22

## Current pass: deepen include-only modules

### Hypothesis

Moving state and declarations to their owning include-only modules can remove false dependencies without changing runtime behavior.

### Scope

1. Move cross-module forward declarations out of `PMBanner.xm.inc` into one internal declaration include.
2. Move Banner, Global SpringBoard, and Float state into their owning modules.
3. Remove Float state/configuration from `PMDiagnostic.xm.inc` so diagnostics can later be deleted independently.
4. Rename banner-only generic helpers to `PMBanner*` names.
5. Remove stale comments and diff-check whitespace findings.

### Success criteria

- Makefile, package metadata, injection filter, hook implementations, hook order, keepalive constants, and version remain unchanged.
- All existing C/Objective-C function bodies remain unchanged except identifier renames required by ownership cleanup.
- Logos directive sequence remains unchanged.
- Fresh arm64 + arm64e compile succeeds.
- `git diff --check` passes.

### Independent failure signals

- Any `%hook`, replacement hook, or `%ctor` addition/removal/reordering.
- Any keepalive timing, frame-rate range, dirty-layer, notification, or lifecycle constant changes.
- New compiler/linker errors or warnings attributable to this refactor.
- Diagnostic-disabled build no longer compiles.

### Evidence plan

- Review the exact diff from `5975bee`.
- Compare normalized source tokens after mapping renamed banner identifiers.
- Compare Logos directive sequence before/after.
- Run a clean local package build as compile smoke validation.

## Verification result

- `git diff --check`: pass.
- Package metadata and injection filter unchanged: `control`, `ProMotion120.plist`.
- `Makefile` intentionally changed from `Tweak.xm` to `Tweak.xmi` for CPP-before-Logos module expansion.
- Logos directive sequence unchanged: 100 entries, same order.
- Normalized function set unchanged: 105 functions; no function-body changes after mapping the two banner renames.
- Normalized token delta is only the removal of one redundant `PMFPSRecordRange` forward declaration.
- Clean local arm64 + arm64e package build: pass (`BUILD_STATUS=0`).
- Local arm64e link still emits the known incompatible-ABI warning; local package remains compile-smoke only and must not be delivered.
- Independent review found no P0/P1 regression; the new load-bearing declaration include must be included in any future commit/push.

## Hook-layer split

### Design decision

- Plain `#include` inside `.xm` does not preprocess included `%hook` directives; a minimal probe failed as expected.
- Theos `.xmi` runs the C preprocessor before Logos. A minimal `.xmi` probe proved that `%hook` files included with `#include` are expanded and processed correctly.
- `rootless.h` was unused and incompatible with the `.xmi` preprocessing stage because of its `libroot` module import, so the unused import was removed.

### Modules

- `PMSystemHooks.xm.inc`: SpringBoard policy/controller and `UIScreen` hooks.
- `PMRenderingHooks.xm.inc`: `CADisplayLink`, CoreAnimation, CAMetalLayer/drawable, and Metal command-buffer hooks.
- `PMUIKitHooks.xm.inc`: view/controller/window/scroll/menu/overlay hooks.
- `PMRuntimeHooks.xm.inc`: dynamic Objective-C runtime hooks, replacements, and installers.
- `PMBootstrap.xm.inc`: the single `%ctor` composition root.
- `Tweak.xmi`: imports, constants, interfaces, and ordered module includes only.

### Hook-split verification

- Throwaway split probe compiled for arm64 + arm64e before applying to the worktree.
- Formal clean local build passed (`BUILD_STATUS=0`).
- Generated Logos intermediates contain no unprocessed `%hook`, `%orig`, `%end`, or `%ctor` directives.
- Split and unsplit local dylibs have identical size (`236480` bytes), architecture slices, linked libraries, defined/undefined symbol sets, Objective-C selector/class strings, and package metadata/plist.
- arm64 and arm64e machine-code disassembly are byte-for-byte identical. Binary hash differences are limited to generated UUID/code-signature data.
- Independent hook-split review found no P0 and no hook/constructor/include-order regression. Ship gate: all new `.xmi`/`.xm.inc` files must be included in the eventual commit.
- GitHub Actions path filters now include `**/*.xmi` and `**/*.inc`, so later module-only edits trigger both roothide and rootless workflows.

## Foreground app probe 1

### Baseline

- Production behavior baseline: `8d7ce89` (`1.0.9+clean2`).
- Diagnostic starting point: `6312bd4` (`diag/telegram-chat-probe`).
- Working branch: `diagnostic/foreground-app-probe1`.

### Hypothesis

Hard-coded Telegram bundle IDs are unnecessary. Because ProMotion120 already injects into UIKit app processes, a compile-time-isolated probe can observe only the currently active app, keep hot-path evidence in bounded atomic counters, and write a bundle-identified snapshot when that app resigns active or receives an explicit marker. This should cover arbitrary Telegram forks without adding per-frame queueing or disk I/O.

### Success criteria

- Remove Telegram/Nicegram bundle matching and all rejected-app plist writes.
- Do not dispatch, allocate collections/strings, or write files from DisplayLink/range/scroll/Metal hot hooks.
- Record only while the app process is active; reset counters at each foreground session.
- Write a unique bundle-identified plist only on app resign or `com.doimty.promotion120.probe.mark.drop`.
- Snapshot includes bundle/version/pid, capture span, source liveness, requested range counters, scroll counters, Metal-present cadence buckets, last-event monotonic times, and the trigger.
- `PM_FOREGROUND_PROBE_ENABLED=0` excludes the implementation and all probe strings from a clean binary.
- Existing ProMotion hook order, active 120Hz behavior, keepalive/Float/Banner state machines, ranges, and timing constants remain unchanged.
- Probe-enabled and probe-disabled local builds compile; cloud roothide artifact has correct arm64e ABI and no incompatible-ABI warning.

### Independent failure signals

- Any production hook, forced range, high-frame-rate reason, keepalive tick/evaluate behavior, lifecycle hold, or process filter changes.
- Any unbounded queue or collection fed by a per-frame hook.
- Any file write before an explicit marker or foreground-session end.
- Probe filenames collide across bundle IDs or system/non-target processes overwrite the target app snapshot.
- A clean build contains `foreground-probe`, marker notification, or probe-version strings.

### Ablation expectations

- Probe enabled versus disabled must differ only by observation calls and probe lifecycle registration; forced output ranges and runtime hook composition stay identical.
- Removing bundle-name matching must not affect ProMotion eligibility because the matcher was diagnostic-only.
- With no marker and no resign event, no probe plist is created.
- On resign, exactly the resigning app writes its own bundle-specific snapshot; on marker, only active app processes write snapshots.

### Evidence plan

- Static hot-path scan and source contract checker.
- Diff production function bodies and Logos directive order against `8d7ce89` after accounting for probe calls.
- Compile with `PM_FOREGROUND_PROBE_ENABLED=1` and `0`.
- Extract both packages and scan clean/probe strings and substrate filter.
- Use macOS cloud roothide build for any device-delivered arm64e package.

### Verification

- Source contract (scripts/check-foreground-probe.sh): 22 checks pass.
- Package verification (scripts/verify-foreground-probe-package.sh): probe-on produces roothide arm64e with expected strings; probe-off has no probe strings and passes jbroot check.
- Binary equivalence: probe-off vs baseline `8d7ce89` — arm64e symbols, disassembly, __cstring, __objc_methname, __objc_classname, __objc_methtype all identical.
- Correctness review (sub-agent): P1 writer boundary, coherent range snapshot, marker generation binding, CAS timestamp race — all fixed.
- Build/isolation review (sub-agent): P1 probe-off CI, ABI gate, roothide assertion — all fixed.
- Concurrent pended-marker handling: marker accepted in backgrounded callback merged into foregroundEnd snapshot with `marker.drop+foregroundEnd` reason.
- Run `29925794568` did not reach checkout or compilation. Its sole annotation reports failed account payment or an insufficient Actions spending limit.
- Workflow regression gate now proves build pipeline failures propagate through `tee`, preserves the probe-on deb before the probe-off isolation build, and uploads only the preserved diagnostic package.
- Fallback macOS run `29927454537` built commit `50dbe0a371ad0b35cac619394017d4530531ad8c`: probe-on and probe-off package gates passed, compiler-error and incompatible-arm64e scans were clean, and the uploaded artifact contains only the preserved probe-on deb.
- Verified cloud deb SHA256: `49edcc87463f784717ed8414fbec818c8da05511f13d956f6e77be2c064bfa40`.

## Foreground app probe 2: visible log output

### Baseline

- Behavior/source baseline: `953940a` (`1.0.9+fgprobe1`).
- Working branch: `diagnostic/foreground-app-probe2-visible-log`.

### Hypothesis

`/var/tmp` is not a reliable user-visible retrieval location on the target roothide setup, and marker/background-only output gives no immediate proof that injection succeeded. Matching the previously validated ProMotion/Insulation probe convention should make diagnostics observable without changing high-refresh behavior.

### Success criteria

- Write a per-bundle stable latest snapshot at `/var/mobile/Library/Preferences/com.promotion120.foreground-probe.<bundle-prefix>.h<bundle-hash>.latest.plist`, preventing delayed snapshots and truncated-name collisions from another app from overwriting it.
- Keep a unique bundle/version/pid/session history snapshot in the same visible directory.
- Emit one `foregroundStart` receipt when an app becomes active; marker and foreground-end snapshots remain supported.
- Record per-path success/error details in the plist and retain `/tmp` only as a fallback.
- Keep all write/serialization work on the existing snapshot queue; hot rendering hooks remain atomic-only.
- Probe-off build remains binary-equivalent to `8d7ce89`; cloud roothide arm64e package has no incompatible-ABI warning.

### Independent failure signals

- The package contains only `/var/tmp` output paths or lacks the per-bundle stable latest preference path.
- Foreground activation cannot produce a snapshot without a marker.
- Marker notifications can enqueue more than one disk snapshot per process, or one app can overwrite another app's latest snapshot.
- Path/error reporting itself causes recursive writes or unbounded retries.
- Any high-refresh hook order, forced range, keepalive, Float, Banner, or injection filter change.

### Verification

- Source contract passes with explicit gates for per-bundle hashed latest paths, immediate foreground receipt, mutex-bound marker ownership, session-drained marker admission, nonblocking lifecycle writes, arm64e Mach-O subtype, probe artifact isolation, and cloud clean2 comparison.
- Local probe-on and probe-off builds compile and pass package verification; local Linux arm64e output retains the known incompatible-ABI linker warning and is compile evidence only, never deliverable.
- Fresh local probe-off comparison against `8d7ce89` passes for exported symbols, normalized disassembly, and `__cstring`/Objective-C name/type sections.
- Three adversarial review passes found and drove fixes for snapshot dropping, misleading two-pass telemetry, main-thread disk waits, cross-app latest collisions, unbounded marker writes, truncated bundle collisions, and marker token TOCTOU; final review reports no P0/P1 findings.
- Fallback macOS run `29934468752` built code commit `1479eb73efa0d6cc38a9b4b41778bd91ffbea15d`: probe-on/off and clean2 baseline builds passed, actual Mach-O subtype and roothide dependency checks passed, cloud logs contain no incompatible-arm64e or compiler-fatal signal, and the artifact contains only the preserved probe-on deb.
- Verified cloud deb SHA256: `3845b93fba1ed416674202dfd346120471b1815b8797e2e1dbb63cd52c22e2f1`.

## 1.0.11 render-pacing ablation candidate

### Baseline

- Source line: `cloud/rootless-1.0.11`.
- Baseline commit: `bcef7cab7d681906e1b119c519b150a25dc6e0b3`.
- Behavioral release base: `44e647ff0119d5ab9ec0ef743ab3daebeeddc003` (`1.0.11 clean`).
- User symptom: occasional frame drops during screen recording and in Telegram.

### Hypothesis

The global Metal hooks may override app and screen-recording GPU pacing in a way that increases contention or latency. If they are the cause, preserving the app's own Metal present cadence while retaining CADisplayLink, CAAnimation, and DynamicSource 120Hz requests should reduce intermittent drops.

### Candidate change

- Remove the global `CAMetalLayer.maximumDrawableCount` override.
- Remove the global `CAMetalDrawable.presentAfterMinimumDuration:` override.
- Remove the global `MTLCommandBuffer.presentDrawable:afterMinimumDuration:` override.
- Remove the now-unused Metal header import.
- Keep all 120Hz request paths, persistent app DynamicSource, SpringBoard keepalive, and non-Metal hooks unchanged.
- Add `scripts/verify-render-pacing-ablation.sh` as a source contract.

### Current evidence

- Candidate contract: pass (6 checks).
- Existing keepalive contract: pass (13 checks).
- `git diff --check`: pass.
- Local Theos is absent, so no local iOS compile was possible. `make -n` stops at `THEOS` unset; this is an environment limitation, not a source compile result.
- No iOS 15 device frame-time trace is available yet. The candidate is not device-accepted and must not be delivered as a confirmed fix until the same Telegram/recording scenario is compared against baseline.

## Post-device source audit for 1.0.13 after 1.0.12 feedback

- Device feedback: 1.0.12 feels smoother in the tested scenario.
- Fixed a keepalive target lifetime regression in `src/PMKeepAlive.xm.inc`: retain `PMSBKeepAliveTargetInstance` for the lifetime of the persistent `CADisplayLink` instead of relying on a local installation variable.
- Fixed an app-source retry gap in `src/PMAppPersistent.xm.inc`: `PMAppRefreshPersistentSource()` now retries `PMAppEnsurePersistentSource()` when the delayed first creation races main-display initialization.
- Fixed startup probe and installation retry gaps: early empty `CADisplay.availableModes` no longer permanently disables the tweak; bootstrap retries initialization for a bounded window; DynamicSource hooks are idempotent across late-install retries; SpringBoard keepalive installation retries a bounded number of times.
- Static checks pass after these fixes. Version is now 1.0.13.
- Pinned roothide build passed in GitHub Actions run `35511731356` at commit `0bea5cf`: macOS 14 runner, Xcode 15.4 (`15F31d`), Apple clang 15.0.0, iPhoneOS SDK 16.5, no `incompatible arm64e ABI compiler` warning.
- Final roothide artifact: `com.doimty.promotion_1.0.13_iphoneos-arm64e.deb`, SHA256 `7872a0928964eaed12a8ca3b6743580015c894296ba4979ca3b0e4a574499b64`. Package metadata and Mach-O arm64e header verified; required DynamicSource, keepalive, and frame-rate selectors are present.
- Pinned rootless build passed in GitHub Actions run `35512146221` at the same commit, with Xcode 15.4 (`15F31d`), Apple clang 15.0.0, iPhoneOS SDK 16.5, and no `incompatible arm64e ABI compiler` warning.
- Final rootless artifact: `com.doimty.promotion_1.0.13_iphoneos-arm64.deb`, SHA256 `a126a981a550dd08e4845df8d6fbb37d5aa5d9e2c68a7ef22785070f9e508986`.
- Published both artifacts to `https://doimty.github.io/`. Live `Packages` contains exactly the two 1.0.13 architecture stanzas; live `.deb` downloads return HTTP 200 and match the build SHA256 values; `Packages`, `Packages.gz`, `Packages.xz`, and `Packages.lzma` match the live `Release` checksums.
- Boundary: UIKit/CADisplayLink/CAAnimation requests can be raised from 60 to 120 when the app submits frames through those paths. A Metal/video/recording producer that submits only 60 unique frames cannot be made into true 120fps by changing display policy alone; forcing Metal present timing globally was removed in 1.0.12 because it competed with app and recorder pacing.
