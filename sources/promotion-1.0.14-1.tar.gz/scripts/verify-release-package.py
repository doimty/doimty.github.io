#!/usr/bin/env python3
"""Read-only package checks; optional byte/mode-preserving numeric-root repack.

Never executes maintainer scripts or target binaries. Signature checks validate
hash integrity, not provisioning, AMFI acceptance, PAC or device behavior.
"""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import plistlib
import subprocess
import tarfile
import tempfile
from inspect_release_macho import inspect

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('release_metadata', ROOT / 'scripts/stage-release-metadata.py')
metadata = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metadata)


def records(package, flag, require_root=True):
    blob = subprocess.check_output(['dpkg-deb', flag, str(package)])
    result = {}
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        for entry in archive:
            path = PurePosixPath(entry.name)
            if path.is_absolute() or '..' in path.parts or '\\' in entry.name:
                raise ValueError('Unsafe archive path')
            name = str(path)
            if name in result or not (entry.isfile() or entry.isdir()):
                raise ValueError('Duplicate/link/special archive entry')
            if require_root and (entry.uid, entry.gid) != (0, 0):
                raise ValueError('Non-root numeric archive ownership')
            if entry.size > 4 * 1024 * 1024:
                raise ValueError('Oversized release entry')
            data = archive.extractfile(entry).read() if entry.isfile() else b''
            result[name] = {'kind': 'file' if entry.isfile() else 'directory',
                            'mode': entry.mode, 'uid': entry.uid, 'gid': entry.gid, 'data': data}
    return result


def verify(package, scheme, require_root=True):
    package = Path(package)
    data = records(package, '--fsys-tarfile', require_root)
    control = records(package, '--ctrl-tarfile', require_root)
    if {n for n, r in control.items() if r['kind'] == 'file'} != {'control'}:
        raise ValueError('Unexpected control payload')
    if set(control) - {'.', 'control'}:
        raise ValueError('Unexpected control directory')
    meta = metadata.parse_control(control['control']['data'].decode())
    metadata.verify_metadata(meta, scheme)
    prefix = 'var/jb/' if scheme == 'rootless' else ''
    directory = prefix + 'Library/MobileSubstrate/DynamicLibraries/'
    library, filter_name = directory + 'ProMotion120.dylib', directory + 'ProMotion120.plist'
    if {n for n, r in data.items() if r['kind'] == 'file'} != {library, filter_name}:
        raise ValueError('Wrong scheme prefix or unexpected payload')
    directories = {'.'} | {str(p) for p in PurePosixPath(library).parents}
    if set(data) - directories - {library, filter_name}:
        raise ValueError('Unexpected payload directory')
    for listing in (data, control):
        for name, record in listing.items():
            expected_mode = 0o755 if record['kind'] == 'directory' or name == library else 0o644
            if record['mode'] != expected_mode:
                raise ValueError('Wrong permission mode: ' + name)
    expected_filter = plistlib.loads((ROOT / 'ProMotion120.plist').read_bytes())
    if plistlib.loads(data[filter_name]['data']) != expected_filter:
        raise ValueError('Injection filter differs from hdr1')
    macho = inspect(data[library]['data'], scheme)
    return {'scheme': scheme, 'version': meta['Version'], 'architecture': meta['Architecture'],
            'package': package.name, 'sha256': hashlib.sha256(package.read_bytes()).hexdigest(),
            'bytes': package.stat().st_size, 'data_records': len(data), 'control_records': len(control),
            'numeric_root_checked': require_root, 'macho': macho,
            'scope': 'archive and static signature integrity; not device validation'}


def snapshot(listing):
    return {n: (r['kind'], r['mode'], hashlib.sha256(r['data']).hexdigest()) for n, r in listing.items()}


def canonicalize(package, scheme):
    package = Path(package).resolve()
    # Verify paths/types/modes/control/signatures before extraction; ownership is
    # the only property deliberately repaired. No scripts are ever executed.
    verify(package, scheme, require_root=False)
    before = records(package, '--fsys-tarfile', False)
    control_before = records(package, '--ctrl-tarfile', False)
    with tempfile.TemporaryDirectory(prefix='pm-release-', dir=package.parent, ignore_cleanup_errors=True) as tmp:
        stage, rebuilt = Path(tmp) / 'stage', Path(tmp) / 'rebuilt.deb'
        subprocess.run(['dpkg-deb', '--raw-extract', str(package), str(stage)], check=True, stdout=subprocess.DEVNULL)
        for name, record in before.items():
            os.chmod(stage / name, record['mode'])
        for name, record in control_before.items():
            os.chmod(stage / 'DEBIAN' / name, record['mode'])
        subprocess.run(['dpkg-deb', '--build', '--root-owner-group', '-Zxz', str(stage), str(rebuilt)],
                       check=True, stdout=subprocess.DEVNULL)
        if snapshot(records(rebuilt, '--fsys-tarfile')) != snapshot(before):
            raise ValueError('Repack changed data bytes/types/modes')
        if snapshot(records(rebuilt, '--ctrl-tarfile')) != snapshot(control_before):
            raise ValueError('Repack changed control bytes/types/modes')
        verify(rebuilt, scheme)
        os.replace(rebuilt, package)
    report = verify(package, scheme)
    report['repack_bytes_types_modes_unchanged'] = True
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    parser.add_argument('--scheme', choices=metadata.SCHEMES, required=True)
    parser.add_argument('--canonicalize', action='store_true')
    args = parser.parse_args()
    result = canonicalize(args.package, args.scheme) if args.canonicalize else verify(args.package, args.scheme)
    print(json.dumps(result, indent=2))
