#!/usr/bin/env python3
"""Fail closed on recording artifacts in current release source/staged deb.

Historical docs are deliberately excluded. This checks known retired-module
signatures, not proof that arbitrary stripped/obfuscated code is absent.
"""
import argparse
from pathlib import Path
import plistlib
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MARKERS = (b'ProMotion120Recording', b'PMRecording', b'PM_RECORDING_',
           b'Recording.xmi', b'replayd', b'FigScreenCaptureController')


def inspect_file(path):
    errors = []
    if path.is_symlink():
        # Do not silently skip escaped/renamed package payloads.
        return [f'{path}: unexpected symlink in release payload']
    data = path.read_bytes()
    for marker in MARKERS:
        if marker.lower() in data.lower() or marker.lower() in path.name.encode().lower():
            errors.append(f'{path}: retired recording marker {marker.decode()}')
    if path.suffix == '.plist':
        try:
            decoded = plistlib.loads(data)
        except Exception as exc:
            errors.append(f'{path}: invalid plist: {exc}')
        else:
            if 'replayd' in repr(decoded).lower():
                errors.append(f'{path}: replayd filter is forbidden')
    return errors


def check_source(root):
    errors = []
    makefile = (root / 'Makefile').read_text()
    targets = re.findall(r'^TWEAK_NAME\s*(?:\+?=|:=)\s*(.*?)\s*$', makefile, re.M)
    if targets != ['ProMotion120']:
        errors.append(f'Makefile: unexpected release targets {targets!r}')
    if not re.search(r'^ProMotion120_FILES\s*=\s*Tweak\.xmi\s*$', makefile, re.M):
        errors.append('Makefile: main target source contract changed')
    if re.search(r'AVFoundation|CoreMedia', makefile):
        errors.append('Makefile: recording-only framework dependency remains')
    files = [root / 'Makefile', root / 'Tweak.xmi', *root.glob('*.plist'), *root.glob('*.xmi')]
    for directory in ['src', 'layout', '.github/workflows']:
        files.extend(p for p in (root / directory).rglob('*') if p.is_file() or p.is_symlink())
    for path in sorted(set(files)):
        errors.extend(inspect_file(path))
    for relative in ['ProMotion120.plist', 'layout/Library/MobileSubstrate/DynamicLibraries/ProMotion120.plist']:
        if not (root / relative).is_file():
            errors.append(f'missing main filter: {relative}')
    return errors


def check_package(root):
    errors = []
    files = [p for p in root.rglob('*') if p.is_file() or p.is_symlink()]
    libraries = [p for p in files if p.suffix == '.dylib']
    if len(libraries) != 1 or libraries[0].name != 'ProMotion120.dylib':
        errors.append('package must contain exactly one dylib: ProMotion120.dylib')
    filters = [p for p in files if p.suffix == '.plist' and p.parent.name == 'DynamicLibraries']
    if len(filters) != 1 or filters[0].name != 'ProMotion120.plist':
        errors.append('package must contain exactly one injection filter: ProMotion120.plist')
    for path in files:
        errors.extend(inspect_file(path))
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--deb', type=Path)
    parser.add_argument('--package-root', type=Path)
    args = parser.parse_args()
    errors = check_source(args.root)
    if args.package_root:
        errors.extend(check_package(args.package_root))
    if args.deb:
        with tempfile.TemporaryDirectory(prefix='pm120-no-recording-') as tmp:
            subprocess.run(['dpkg-deb', '-x', str(args.deb.resolve()), tmp], check=True)
            errors.extend(check_package(Path(tmp)))
    for error in errors:
        print('FAIL:', error)
    if errors:
        return 1
    print('PASS: no recording release contract' + ('; unpacked payload checked' if args.deb or args.package_root else ' (source only)'))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
