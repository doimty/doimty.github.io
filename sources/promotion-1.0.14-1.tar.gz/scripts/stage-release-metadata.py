#!/usr/bin/env python3
"""Verify release identity and add only scheme-specific staged metadata."""
import argparse
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SCHEMES = {'roothide': 'iphoneos-arm64e', 'rootless': 'iphoneos-arm64'}


def parse_control(text):
    result = {}
    for line in text.splitlines():
        if not line:
            continue
        if ':' not in line or line[:1].isspace():
            raise ValueError('Unsupported control syntax')
        key, value = line.split(':', 1)
        if key in result:
            raise ValueError('Duplicate control key: ' + key)
        result[key] = value.strip()
    return result


def verify_metadata(metadata, scheme, source=None):
    source = source or parse_control((ROOT / 'control').read_text())
    if not re.fullmatch(r'\d+(?:\.\d+)*-\d+', source['Version']):
        raise ValueError('Formal version must use numeric version and revision')
    for key, value in source.items():
        if key == 'Architecture':
            value = SCHEMES[scheme]
        if metadata.get(key) != value:
            raise ValueError('Wrong ' + key + ' for ' + scheme)
    if set(metadata) - set(source) - {'Tag', 'Installed-Size'}:
        raise ValueError('Unexpected release metadata fields')
    expected_tag = 'supports::roothide' if scheme == 'roothide' else None
    if metadata.get('Tag') != expected_tag:
        raise ValueError('Wrong environment support tag')
    if not metadata.get('Installed-Size', '').isdigit():
        raise ValueError('Missing generated Installed-Size')
    return metadata


def stage(path, scheme):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Missing regular staged control file')
    text = path.read_text()
    metadata = parse_control(text)
    if 'Tag' in metadata:
        # A repeated make package must be idempotent, but a rootless control
        # may never inherit a RootHide marker from an earlier scheme.
        verify_metadata(metadata, scheme)
        return
    if scheme == 'roothide':
        text = text.rstrip('\n') + '\nTag: supports::roothide\n'
    verify_metadata(parse_control(text), scheme)
    path.write_text(text)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scheme', choices=SCHEMES, required=True)
    parser.add_argument('--control', type=Path, required=True)
    args = parser.parse_args()
    stage(args.control, args.scheme)
    print('PASS: staged release metadata (' + args.scheme + ')')
