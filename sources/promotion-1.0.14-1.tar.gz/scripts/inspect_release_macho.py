"""Static Mach-O identity and code-page validation, not AMFI/PAC/runtime proof.

Signature hashing is reused from the existing Vedette release auditor.
"""
from pathlib import Path
import hashlib
import math
import struct


def be32(data, offset):
    return struct.unpack_from('>I', data, offset)[0]


def cstr(data, offset):
    assert 0 <= offset < len(data)
    return data[offset:data.index(0, offset)].decode('utf-8')


def signature(data, offset, size):
    blob = data[offset:offset + size]
    assert len(blob) == size and be32(blob, 0) == 0xfade0cc0
    length, count = be32(blob, 4), be32(blob, 8)
    assert 12 + count * 8 <= length <= size
    blobs = {}
    for i in range(count):
        slot, start = struct.unpack_from('>II', blob, 12 + i * 8)
        assert slot not in blobs and 12 + count * 8 <= start and start + 8 <= length
        end = start + be32(blob, start + 4)
        assert start + 8 <= end <= length
        blobs[slot] = blob[start:end]
    assert 0 in blobs and be32(blobs[0], 0) == 0xfade0c02, 'Missing primary CodeDirectory'
    results = []
    for slot, cd in blobs.items():
        if be32(cd, 0) != 0xfade0c02:
            continue
        ver, flags, hash_off, ident_off, special, slots, limit = struct.unpack_from('>7I', cd, 8)
        hash_size, hash_type, platform, page_pow = struct.unpack_from('4B', cd, 36)
        if ver >= 0x20300 and limit == 0xffffffff:
            limit = struct.unpack_from('>Q', cd, 56)[0]
        algorithm = {1: 'sha1', 2: 'sha256', 3: 'sha256', 4: 'sha384'}[hash_type]
        assert hash_size in (20, 32, 48) and page_pow <= 20
        page = (1 << page_pow) if page_pow else max(limit, 1)
        assert 0 < limit <= offset and slots == math.ceil(limit / page)
        assert hash_off - special * hash_size >= 0 and hash_off + slots * hash_size <= len(cd)
        for n in range(slots):
            raw = data[n * page:min((n + 1) * page, limit)]
            expected = hashlib.new(algorithm, raw).digest()[:hash_size]
            assert cd[hash_off + n * hash_size:hash_off + (n + 1) * hash_size] == expected, 'Code page hash mismatch'
        special_checked = []
        for n in range(1, special + 1):
            expected = cd[hash_off - n * hash_size:hash_off - (n - 1) * hash_size]
            if expected == bytes(hash_size):
                continue
            assert n in blobs, 'Unverified external signature slot'
            assert hashlib.new(algorithm, blobs[n]).digest()[:hash_size] == expected
            special_checked.append(n)
        results.append({'slot': slot, 'identifier': cstr(cd, ident_off), 'hash': algorithm,
                        'code_pages': slots, 'code_pages_verified': True,
                        'special_slots_verified': special_checked})
    return results


def inspect(data, scheme):
    assert scheme in ('rootless', 'roothide')
    slices = []
    if data[:4] == b'\xcf\xfa\xed\xfe':
        slices.append((None, None, data))
    else:
        assert data[:4] == b'\xca\xfe\xba\xbe', 'Unsupported Mach-O format'
        count = be32(data, 4)
        assert count == 2
        intervals = []
        for i in range(count):
            cpu, subtype, offset, size, align = struct.unpack_from('>5I', data, 8 + 20 * i)
            assert align <= 20 and offset >= 8 + 20 * count and offset % (1 << align) == 0
            assert size > 32 and offset + size <= len(data)
            assert all(offset + size <= start or offset >= end for start, end in intervals)
            intervals.append((offset, offset + size))
            slices.append((cpu, subtype, data[offset:offset + size]))
    result = []
    for fat_cpu, fat_subtype, binary in slices:
        magic, cpu, subtype, kind, count, cmdsize, flags, reserved = struct.unpack_from('<8I', binary)
        assert magic == 0xfeedfacf and cpu == 0x100000c and kind == 6
        assert subtype & 0xffffff in (0, 2)
        if fat_cpu is not None:
            assert (fat_cpu, fat_subtype) == (cpu, subtype)
        pos = 32
        deps, ids, rpaths, versions, signatures = [], [], [], [], []
        for _ in range(count):
            cmd, length = struct.unpack_from('<II', binary, pos)
            assert length >= 8 and pos + length <= 32 + cmdsize <= len(binary)
            block = binary[pos:pos + length]
            if cmd in (0xc, 0xd, 0x80000018, 0x8000001f, 0x80000023, 0x8000001c):
                name = cstr(block, struct.unpack_from('<I', block, 8)[0])
                (ids if cmd == 0xd else rpaths if cmd == 0x8000001c else deps).append(name)
            if cmd == 0x32:
                platform, minimum, sdk, tools = struct.unpack_from('<4I', block, 8)
                assert (platform, minimum, sdk) == (2, 0xf0000, 0x110500), 'Wrong iOS minimum/SDK'
                versions.append({'minimum': '15.0', 'sdk': '17.5', 'platform': platform})
            if cmd == 0x1d:
                start, size = struct.unpack_from('<II', block, 8)
                assert start + size <= len(binary)
                signatures.append(signature(binary, start, size))
            if cmd == 0x2c:
                assert struct.unpack_from('<I', block, 16)[0] == 0, 'Encrypted binary'
            pos += length
        assert pos == 32 + cmdsize and len(versions) == 1 and len(signatures) == 1
        assert not any(x in dep for dep in deps for x in ('AVFoundation', 'CoreMedia', 'ReplayKit'))
        if scheme == 'roothide':
            assert ids == ['@loader_path/.jbroot/Library/MobileSubstrate/DynamicLibraries/ProMotion120.dylib']
            assert '@loader_path/.jbroot/usr/lib/libsubstrate.dylib' in deps
            assert not any('/var/jb' in value for value in deps + ids + rpaths)
        else:
            assert ids == ['@rpath/ProMotion120.dylib']
            assert '/var/jb/usr/lib' in rpaths and '/var/jb/Library/Frameworks' in rpaths
            # Pinned roothide/lib rootless/libsubstrate.tbd is a symlink to
            # CydiaSubstrate.framework, whose install-name is this @rpath.
            assert '@rpath/CydiaSubstrate.framework/CydiaSubstrate' in deps
            assert not any('libroothide' in dep or '@loader_path/.jbroot/' in dep for dep in deps)
        result.append({'arch': 'arm64e' if subtype & 0xffffff == 2 else 'arm64',
                       **versions[0], 'dependencies': deps, 'id': ids, 'rpaths': rpaths,
                       'signatures': signatures[0]})
    expected = {'arm64', 'arm64e'} if scheme == 'rootless' else {'arm64e'}
    assert len(result) == len(expected) and {x['arch'] for x in result} == expected, 'Wrong CPU slices'
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'slices': result}
