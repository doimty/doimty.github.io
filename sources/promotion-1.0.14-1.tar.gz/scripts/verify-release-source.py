#!/usr/bin/env python3
"""Byte/mode freeze of the positively reported hdr1 production implementation."""
import argparse
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parents[1]


def check(root=ROOT):
    root = Path(root)
    manifest = json.loads((root / 'tests/release-baseline.json').read_text())
    expected = manifest['files']
    actual = {'Tweak.xmi', 'ProMotion120.plist',
              'layout/Library/MobileSubstrate/DynamicLibraries/ProMotion120.plist'}
    actual.update(p.relative_to(root).as_posix() for p in (root / 'src').rglob('*')
                  if p.is_file() or p.is_symlink())
    if actual != set(expected):
        raise ValueError('Production file set differs from hdr1')
    for name, record in expected.items():
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError('Missing regular production file: ' + name)
        if hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
            raise ValueError('Production bytes changed: ' + name)
        mode = stat.S_IMODE(path.stat().st_mode)
        if mode != int(record['mode'], 8):
            raise ValueError('Production mode changed: ' + name)
    return {'baseline': manifest['baseline'], 'files_checked': len(expected),
            'bytes_and_modes_unchanged': True, 'scope': 'source freeze, not device validation'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    print(json.dumps(check(args.root), indent=2))
